from datetime import datetime, timezone
from uuid import UUID, uuid4

from app.events import DeviceOfflineAlert
from app.models import Device, DeviceCreate, DeviceStatus
from app.repositories.device_repository import InMemoryDeviceRepository


class DeviceService:
    def __init__(self, repository: InMemoryDeviceRepository) -> None:
        self._repository = repository

    def register_device(self, payload: DeviceCreate) -> Device:
        if self._repository.get_by_ip(payload.ip_address) is not None:
            raise ValueError(f"A device with IP address {payload.ip_address} already exists")

        device = Device(
            device_id=uuid4(),
            name=payload.name,
            device_type=payload.device_type,
            ip_address=payload.ip_address,
        )
        return self._repository.add(device)

    def list_devices(self) -> list[Device]:
        return self._repository.list_all()

    def get_device(self, device_id: UUID) -> Device | None:
        return self._repository.get(device_id)

    def update_device_status(
        self,
        device_id: UUID,
        new_status: DeviceStatus,
    ) -> Device | None:
        device = self._repository.get(device_id)
        if device is None:
            return None

        if device.status == DeviceStatus.ONLINE and new_status == DeviceStatus.OFFLINE:
            self._repository.add_alert(
                DeviceOfflineAlert(
                    alert_id=uuid4(),
                    device_id=device.device_id,
                    message=f"Device {device.name} is offline",
                    created_at=datetime.now(timezone.utc),
                )
            )

        updated_device = device.model_copy(update={"status": new_status})
        return self._repository.update(updated_device)

    def list_alerts(self) -> list[DeviceOfflineAlert]:
        return self._repository.list_alerts()
