from enum import Enum
from ipaddress import IPv4Address
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class DeviceType(str, Enum):
    ROUTER = "router"
    SWITCH = "switch"
    SERVER = "server"


class DeviceStatus(str, Enum):
    ONLINE = "online"
    OFFLINE = "offline"


class DeviceCreate(BaseModel):
    name: str = Field(min_length=1)
    device_type: DeviceType
    ip_address: IPv4Address


class DeviceStatusUpdate(BaseModel):
    status: DeviceStatus


class Device(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    device_id: UUID
    name: str
    device_type: DeviceType
    ip_address: IPv4Address
    status: DeviceStatus = DeviceStatus.ONLINE
