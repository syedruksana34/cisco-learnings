from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status

from app.dependencies import get_device_service
from app.events import DeviceOfflineAlert
from app.models import Device, DeviceCreate, DeviceStatusUpdate
from app.services.device_service import DeviceService

router = APIRouter()

ServiceDependency = Annotated[DeviceService, Depends(get_device_service)]


@router.post("/devices", response_model=Device, status_code=status.HTTP_201_CREATED)
def register_device(
    payload: DeviceCreate,
    service: ServiceDependency,
) -> Device:
    try:
        return service.register_device(payload)
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(error),
        ) from error


@router.get("/devices", response_model=list[Device])
def list_devices(service: ServiceDependency) -> list[Device]:
    return service.list_devices()


@router.get("/devices/{device_id}", response_model=Device)
def get_device(device_id: UUID, service: ServiceDependency) -> Device:
    device = service.get_device(device_id)
    if device is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found",
        )
    return device


@router.patch("/devices/{device_id}/status", response_model=Device)
def update_device_status(
    device_id: UUID,
    payload: DeviceStatusUpdate,
    service: ServiceDependency,
) -> Device:
    device = service.update_device_status(device_id, payload.status)
    if device is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found",
        )
    return device


@router.get("/alerts", response_model=list[DeviceOfflineAlert])
def list_alerts(service: ServiceDependency) -> list[DeviceOfflineAlert]:
    return service.list_alerts()
