from ipaddress import IPv4Address
from uuid import UUID

from app.events import DeviceOfflineAlert
from app.models import Device


class InMemoryDeviceRepository:
    def __init__(self) -> None:
        self._devices: dict[UUID, Device] = {}
        self._alerts: list[DeviceOfflineAlert] = []

    def add(self, device: Device) -> Device:
        self._devices[device.device_id] = device
        return device

    def get(self, device_id: UUID) -> Device | None:
        return self._devices.get(device_id)

    def get_by_ip(self, ip_address: IPv4Address) -> Device | None:
        return next(
            (device for device in self._devices.values() if device.ip_address == ip_address),
            None,
        )

    def list_all(self) -> list[Device]:
        return list(self._devices.values())

    def update(self, device: Device) -> Device:
        self._devices[device.device_id] = device
        return device

    def add_alert(self, alert: DeviceOfflineAlert) -> None:
        self._alerts.append(alert)

    def list_alerts(self) -> list[DeviceOfflineAlert]:
        return list(self._alerts)
