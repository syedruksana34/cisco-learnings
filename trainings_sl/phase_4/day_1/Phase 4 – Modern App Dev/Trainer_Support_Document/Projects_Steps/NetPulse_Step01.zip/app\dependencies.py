from fastapi import Request

from app.services.device_service import DeviceService


def get_device_service(request: Request) -> DeviceService:
    return request.app.state.device_service
