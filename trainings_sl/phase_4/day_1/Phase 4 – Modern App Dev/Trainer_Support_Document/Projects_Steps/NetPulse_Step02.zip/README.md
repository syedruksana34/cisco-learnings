# NetPulse

NetPulse is a beginner-friendly network device monitoring API built with FastAPI.
It uses an in-memory repository; registered devices and alerts are cleared when
the application restarts.

## Requirements

- Python 3.11 or newer

## Setup (Windows PowerShell)

From the project root:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell prevents environment activation, run the commands below using the
virtual environment's interpreter directly:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Run the API

```powershell
python -m uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs` to try the API. The health endpoint is
available at `http://127.0.0.1:8000/health`.

## Run tests

```powershell
python -m pytest
```

## API endpoints

- `POST /devices` — register a router, switch, or server
- `GET /devices` — list registered devices
- `GET /devices/summary` — aggregate device and status counts
- `GET /devices/{device_id}` — retrieve one device
- `PATCH /devices/{device_id}/status` — set a device to online or offline
- `POST /devices/{device_id}/probe` — return a deterministic simulated probe result
- `GET /alerts` — list alerts generated when a device goes offline
- `GET /health` — API health check

The simulated probe does not contact the network or change device status. Its
deterministic rule uses the final IPv4 octet: even means `reachable`; odd means
`unreachable`.
