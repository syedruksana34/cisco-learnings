from fastapi.testclient import TestClient

from app.main import create_app


def create_client() -> TestClient:
    return TestClient(create_app())


def test_register_device() -> None:
    client = create_client()

    response = client.post(
        "/devices",
        json={
            "name": "Core Router",
            "device_type": "router",
            "ip_address": "192.168.1.1",
        },
    )

    assert response.status_code == 201
    assert response.json()["name"] == "Core Router"
    assert response.json()["status"] == "online"
    assert response.json()["ip_address"] == "192.168.1.1"
    assert response.json()["device_id"]


def test_duplicate_ip_is_rejected() -> None:
    client = create_client()
    payload = {
        "name": "First Device",
        "device_type": "server",
        "ip_address": "10.0.0.2",
    }

    assert client.post("/devices", json=payload).status_code == 201
    duplicate = {**payload, "name": "Second Device"}

    response = client.post("/devices", json=duplicate)

    assert response.status_code == 409


def test_invalid_ipv4_is_rejected() -> None:
    response = create_client().post(
        "/devices",
        json={
            "name": "Invalid Device",
            "device_type": "switch",
            "ip_address": "300.1.1.1",
        },
    )

    assert response.status_code == 422


def test_retrieve_device() -> None:
    client = create_client()
    created = client.post(
        "/devices",
        json={
            "name": "App Server",
            "device_type": "server",
            "ip_address": "10.1.0.5",
        },
    ).json()

    response = client.get(f"/devices/{created['device_id']}")

    assert response.status_code == 200
    assert response.json()["device_id"] == created["device_id"]


def test_missing_device_returns_404() -> None:
    response = create_client().get("/devices/00000000-0000-0000-0000-000000000001")

    assert response.status_code == 404


def test_summary_with_no_devices() -> None:
    response = create_client().get("/devices/summary")

    assert response.status_code == 200
    assert response.json() == {
        "total_devices": 0,
        "online_devices": 0,
        "offline_devices": 0,
        "router_count": 0,
        "switch_count": 0,
        "server_count": 0,
    }


def test_summary_with_mixed_device_types_and_statuses() -> None:
    client = create_client()
    devices = [
        {"name": "Router", "device_type": "router", "ip_address": "10.0.0.1"},
        {"name": "Switch", "device_type": "switch", "ip_address": "10.0.0.2"},
        {"name": "Server A", "device_type": "server", "ip_address": "10.0.0.3"},
        {"name": "Server B", "device_type": "server", "ip_address": "10.0.0.4"},
    ]
    created = [client.post("/devices", json=device).json() for device in devices]
    client.patch(f"/devices/{created[1]['device_id']}/status", json={"status": "offline"})

    response = client.get("/devices/summary")

    assert response.status_code == 200
    assert response.json() == {
        "total_devices": 4,
        "online_devices": 3,
        "offline_devices": 1,
        "router_count": 1,
        "switch_count": 1,
        "server_count": 2,
    }


def test_probe_existing_device_returns_deterministic_simulated_result() -> None:
    client = create_client()
    device = client.post(
        "/devices",
        json={
            "name": "Test Server",
            "device_type": "server",
            "ip_address": "192.168.1.20",
        },
    ).json()

    response = client.post(f"/devices/{device['device_id']}/probe")

    assert response.status_code == 200
    assert response.json() == {
        "device_id": device["device_id"],
        "result": "reachable",
        "simulated": True,
    }


def test_probe_unknown_device_returns_404() -> None:
    response = create_client().post(
        "/devices/00000000-0000-0000-0000-000000000001/probe"
    )

    assert response.status_code == 404


def test_probe_does_not_change_device_status() -> None:
    client = create_client()
    device = client.post(
        "/devices",
        json={
            "name": "Odd Address Server",
            "device_type": "server",
            "ip_address": "192.168.1.21",
        },
    ).json()

    probe = client.post(f"/devices/{device['device_id']}/probe")
    current = client.get(f"/devices/{device['device_id']}")

    assert probe.json()["result"] == "unreachable"
    assert current.json()["status"] == "online"


def test_probe_does_not_generate_alerts() -> None:
    client = create_client()
    device = client.post(
        "/devices",
        json={
            "name": "Test Router",
            "device_type": "router",
            "ip_address": "10.0.0.11",
        },
    ).json()

    response = client.post(f"/devices/{device['device_id']}/probe")

    assert response.status_code == 200
    assert client.get("/alerts").json() == []


def test_online_to_offline_generates_alert() -> None:
    client = create_client()
    device = client.post(
        "/devices",
        json={
            "name": "Edge Switch",
            "device_type": "switch",
            "ip_address": "172.16.0.3",
        },
    ).json()

    update = client.patch(
        f"/devices/{device['device_id']}/status",
        json={"status": "offline"},
    )

    assert update.status_code == 200
    assert update.json()["status"] == "offline"
    alerts = client.get("/alerts")
    assert alerts.status_code == 200
    assert len(alerts.json()) == 1
    assert alerts.json()[0]["device_id"] == device["device_id"]


def test_repeated_offline_update_does_not_duplicate_alert() -> None:
    client = create_client()
    device = client.post(
        "/devices",
        json={
            "name": "Database Server",
            "device_type": "server",
            "ip_address": "192.168.10.8",
        },
    ).json()
    endpoint = f"/devices/{device['device_id']}/status"

    client.patch(endpoint, json={"status": "offline"})
    client.patch(endpoint, json={"status": "offline"})

    assert len(client.get("/alerts").json()) == 1


def test_health_endpoint() -> None:
    response = create_client().get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
