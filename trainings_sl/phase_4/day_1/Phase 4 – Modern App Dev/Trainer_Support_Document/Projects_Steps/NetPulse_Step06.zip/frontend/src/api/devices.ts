import type {
  Device,
  DeviceCreate,
  DeviceStatus,
  DeviceType,
} from '../types/device'

export interface DeviceFilters {
  search?: string
  status?: DeviceStatus
  device_type?: DeviceType
}

export class DeviceApiError extends Error {
  readonly status: number

  constructor(
    message: string,
    status: number,
  ) {
    super(message)
    this.name = 'DeviceApiError'
    this.status = status
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function getErrorMessage(body: unknown): string | null {
  if (!isRecord(body)) {
    return null
  }

  const detail = body.detail
  if (typeof detail === 'string') {
    return detail
  }

  if (Array.isArray(detail)) {
    const messages = detail.flatMap((item) =>
      isRecord(item) && typeof item.msg === 'string' ? [item.msg] : [],
    )
    return messages.length > 0 ? messages.join(' ') : null
  }

  return null
}

export async function getDevices(filters: DeviceFilters = {}): Promise<Device[]> {
  const searchParams = new URLSearchParams()
  const search = filters.search?.trim()

  if (search) {
    searchParams.set('search', search)
  }
  if (filters.status) {
    searchParams.set('status', filters.status)
  }
  if (filters.device_type) {
    searchParams.set('device_type', filters.device_type)
  }

  const query = searchParams.toString()
  const response = await fetch(`/api/devices${query ? `?${query}` : ''}`)

  if (!response.ok) {
    throw new Error(`The API returned an error (${response.status}).`)
  }

  return (await response.json()) as Device[]
}

export async function registerDevice(payload: DeviceCreate): Promise<Device> {
  const response = await fetch('/api/devices', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  })

  if (!response.ok) {
    const responseText = await response.text()
    let responseBody: unknown

    try {
      responseBody = JSON.parse(responseText)
    } catch (error) {
      if (!(error instanceof SyntaxError)) {
        throw error
      }
    }

    throw new DeviceApiError(
      getErrorMessage(responseBody) ??
        `The API returned an error (${response.status}).`,
      response.status,
    )
  }

  return (await response.json()) as Device
}
