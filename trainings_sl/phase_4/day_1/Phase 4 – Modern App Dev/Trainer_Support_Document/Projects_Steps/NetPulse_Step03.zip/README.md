# NetPulse

NetPulse is a beginner-friendly network device monitoring API built with FastAPI.
It uses SQLite with SQLAlchemy 2.x; registered devices and alerts persist when
the application restarts.

## Requirements

- Python 3.11 or newer
- SQLite (included with Python)

## Setup (Windows PowerShell)

From the project root:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell prevents environment activation, run the commands below using the
virtual environment's interpreter directly:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

The application creates `netpulse.db` in the current working directory on
startup. The file is local application data and is ignored by Git.

## Run the API

```powershell
python -m uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs` to try the API. The health endpoint is
available at `http://127.0.0.1:8000/health`.

## Run tests

```powershell
python -m pytest
```

Tests use isolated SQLite files under pytest's temporary directory; they do not
read or modify the local `netpulse.db`.

## API endpoints

- `POST /devices` — register a router, switch, or server
- `GET /devices` — list registered devices
- `GET /devices/summary` — aggregate device and status counts
- `GET /devices/{device_id}` — retrieve one device
- `PATCH /devices/{device_id}/status` — set a device to online or offline
- `POST /devices/{device_id}/probe` — return a deterministic simulated probe result
- `GET /alerts` — list alerts generated when a device goes offline
- `GET /health` — API health check

The simulated probe does not contact the network or change device status. Its
deterministic rule uses the final IPv4 octet: even means `reachable`; odd means
`unreachable`.

## FastAPI, ASGI, and database sessions

FastAPI is an ASGI web framework. Uvicorn is an ASGI server that runs the
application and handles HTTP connections. Traditional WSGI servers use a
synchronous interface intended for frameworks such as Flask; ASGI additionally
supports asynchronous request handling and long-lived connections.

NetPulse currently uses synchronous SQLAlchemy sessions and synchronous route
handlers. FastAPI runs synchronous handlers and dependencies in a worker
threadpool, which keeps blocking database work off the event loop. Each request
gets its own session, which is committed on success and rolled back on errors.
SQLite's `check_same_thread=False` allows connections to be used across the
request's worker-thread handoff; sessions themselves should not be shared
between concurrent requests or tasks.

## SQLite CRUD example

Run the isolated CRUD demonstration with:

```powershell
python -m examples.sqlite_crud_demo
```

It creates a separate temporary database and removes it when the script exits;
it does not touch `netpulse.db`.
