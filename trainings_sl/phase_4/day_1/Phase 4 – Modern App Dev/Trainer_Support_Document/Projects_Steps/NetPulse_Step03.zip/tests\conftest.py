from collections.abc import Generator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import URL, create_engine
from sqlalchemy.engine import Engine

from app.main import create_app


@pytest.fixture
def database_engine(tmp_path: Path) -> Generator[Engine, None, None]:
    database_path = tmp_path / "netpulse_test.db"
    test_engine = create_engine(
        URL.create("sqlite", database=str(database_path)),
        connect_args={"check_same_thread": False},
    )
    yield test_engine
    test_engine.dispose()


@pytest.fixture
def client(database_engine: Engine) -> Generator[TestClient, None, None]:
    with TestClient(create_app(database_engine)) as test_client:
        yield test_client
