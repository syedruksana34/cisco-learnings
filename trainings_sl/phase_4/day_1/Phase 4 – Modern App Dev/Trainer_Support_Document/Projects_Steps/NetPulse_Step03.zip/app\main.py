from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker

from app.db.database import Base, SessionLocal, engine
from app.db.models import AlertRow, DeviceRow
from app.routes.devices import router as devices_router


def create_app(database_engine: Engine | None = None) -> FastAPI:
    selected_engine = engine if database_engine is None else database_engine

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        Base.metadata.create_all(bind=selected_engine)
        yield

    app = FastAPI(title="NetPulse API", version="1.0.0", lifespan=lifespan)
    app.state.engine = selected_engine
    app.state.session_factory = (
        SessionLocal
        if selected_engine is engine
        else sessionmaker(
            bind=selected_engine,
            autoflush=False,
            expire_on_commit=False,
        )
    )
    app.include_router(devices_router)

    @app.get("/health")
    def health_check() -> dict[str, str]:
        return {"status": "ok"}

    return app


app = create_app()
