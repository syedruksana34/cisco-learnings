from datetime import datetime, timezone
from uuid import UUID, uuid4

from app.events import DeviceOfflineAlert
from app.models import (
    Device,
    DeviceCreate,
    DeviceStatus,
    DeviceSummary,
    ProbeResponse,
)
from app.repositories.device_repository import DeviceRepository


class DeviceService:
    def __init__(self, repository: DeviceRepository) -> None:
        self._repository = repository

    def register_device(self, payload: DeviceCreate) -> Device:
        if self._repository.get_by_ip(payload.ip_address) is not None:
            raise ValueError(f"A device with IP address {payload.ip_address} already exists")

        device = Device(
            device_id=uuid4(),
            name=payload.name,
            device_type=payload.device_type,
            ip_address=payload.ip_address,
        )
        return self._repository.add(device)

    def list_devices(self) -> list[Device]:
        return self._repository.list_all()

    def get_summary(self) -> DeviceSummary:
        devices = self._repository.list_all()
        return DeviceSummary(
            total_devices=len(devices),
            online_devices=sum(device.status == DeviceStatus.ONLINE for device in devices),
            offline_devices=sum(device.status == DeviceStatus.OFFLINE for device in devices),
            router_count=sum(device.device_type.value == "router" for device in devices),
            switch_count=sum(device.device_type.value == "switch" for device in devices),
            server_count=sum(device.device_type.value == "server" for device in devices),
        )

    def get_device(self, device_id: UUID) -> Device | None:
        return self._repository.get(device_id)

    def probe_device(self, device_id: UUID) -> ProbeResponse | None:
        device = self._repository.get(device_id)
        if device is None:
            return None

        # Simulation rule: an even final IPv4 octet is reachable; an odd one is not.
        result = "reachable" if device.ip_address.packed[-1] % 2 == 0 else "unreachable"
        return ProbeResponse(device_id=device.device_id, result=result, simulated=True)

    def update_device_status(
        self,
        device_id: UUID,
        new_status: DeviceStatus,
    ) -> Device | None:
        device = self._repository.get(device_id)
        if device is None:
            return None

        should_create_alert = (
            device.status == DeviceStatus.ONLINE and new_status == DeviceStatus.OFFLINE
        )
        updated_device = device.model_copy(update={"status": new_status})
        updated_device = self._repository.update(updated_device)

        if should_create_alert:
            self._repository.add_alert(
                DeviceOfflineAlert(
                    alert_id=uuid4(),
                    device_id=device.device_id,
                    message=f"Device {device.name} is offline",
                    created_at=datetime.now(timezone.utc),
                )
            )

        return updated_device

    def list_alerts(self) -> list[DeviceOfflineAlert]:
        return self._repository.list_alerts()
