import logging
import sys
from threading import Lock
from typing import Any

import structlog

_CONFIGURATION_LOCK = Lock()
_CONFIGURED = False
_SENSITIVE_FIELDS = {"password", "token", "api_key", "authorization", "secret"}
_JSON_HANDLER_MARKER = "_netpulse_json_handler"


def redact_sensitive_fields(
    logger: Any,
    method_name: str,
    event_dict: dict[str, Any],
) -> dict[str, Any]:
    for key in event_dict:
        if isinstance(key, str) and key.lower() in _SENSITIVE_FIELDS:
            event_dict[key] = "***"
    return event_dict


class _CurrentStderr:
    def write(self, message: str) -> int:
        return sys.stderr.write(message)

    def flush(self) -> None:
        sys.stderr.flush()


def configure_logging() -> None:
    global _CONFIGURED

    with _CONFIGURATION_LOCK:
        if _CONFIGURED:
            return

        application_logger = logging.getLogger("netpulse")
        application_logger.setLevel(logging.INFO)
        application_logger.propagate = False
        if not any(
            getattr(handler, _JSON_HANDLER_MARKER, False)
            for handler in application_logger.handlers
        ):
            handler = logging.StreamHandler(_CurrentStderr())
            handler.setFormatter(logging.Formatter("%(message)s"))
            setattr(handler, _JSON_HANDLER_MARKER, True)
            application_logger.addHandler(handler)

        structlog.configure(
            processors=[
                structlog.stdlib.filter_by_level,
                structlog.contextvars.merge_contextvars,
                structlog.stdlib.add_log_level,
                structlog.stdlib.add_logger_name,
                structlog.processors.TimeStamper(fmt="iso", utc=True),
                redact_sensitive_fields,
                structlog.processors.JSONRenderer(),
            ],
            logger_factory=structlog.stdlib.LoggerFactory(),
            wrapper_class=structlog.stdlib.BoundLogger,
            cache_logger_on_first_use=True,
        )
        _CONFIGURED = True
