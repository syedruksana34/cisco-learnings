from enum import Enum
from ipaddress import IPv4Address
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class DeviceType(str, Enum):
    ROUTER = "router"
    SWITCH = "switch"
    SERVER = "server"


class DeviceStatus(str, Enum):
    ONLINE = "online"
    OFFLINE = "offline"


class DeviceCreate(BaseModel):
    name: str = Field(min_length=1)
    device_type: DeviceType
    ip_address: IPv4Address


class DeviceStatusUpdate(BaseModel):
    status: DeviceStatus


class Device(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    device_id: UUID
    name: str
    device_type: DeviceType
    ip_address: IPv4Address
    status: DeviceStatus = DeviceStatus.ONLINE


class DeviceSummary(BaseModel):
    total_devices: int
    online_devices: int
    offline_devices: int
    router_count: int
    switch_count: int
    server_count: int


class ProbeResponse(BaseModel):
    device_id: UUID
    result: Literal["reachable", "unreachable"]
    simulated: bool
