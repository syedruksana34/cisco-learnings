import json
import re
from datetime import datetime
from typing import Any

import structlog
from fastapi.testclient import TestClient
from sqlalchemy.engine import Engine

from app.db.database import get_session
from app.main import create_app


REQUEST_ID_PATTERN = re.compile(r"[A-Za-z0-9_-]{1,64}\Z")


def parse_json_logs(output: str) -> list[dict[str, Any]]:
    return [json.loads(line) for line in output.splitlines() if line.startswith("{")]


def test_generated_request_id_and_completion_log(
    client: TestClient,
    capfd,
) -> None:
    response = client.get("/health?not_logged=private")
    request_id = response.headers["X-Request-ID"]
    output = capfd.readouterr().err
    logs = parse_json_logs(output)

    assert REQUEST_ID_PATTERN.fullmatch(request_id)
    completion = [
        item for item in logs
        if item.get("event") == "request_completed"
        and item.get("request_id") == request_id
    ]
    assert len(completion) == 1
    event = completion[0]
    assert event["level"] == "info"
    assert datetime.fromisoformat(event["timestamp"])
    assert event["method"] == "GET"
    assert event["path"] == "/health"
    assert "not_logged" not in event["path"]
    assert event["status_code"] == 200
    assert isinstance(event["duration_ms"], (int, float))
    assert event["duration_ms"] >= 0


def test_valid_supplied_request_id_is_returned_and_correlated(
    client: TestClient,
    capfd,
) -> None:
    request_id = "client_trace-123"
    response = client.get("/health", headers={"X-Request-ID": request_id})
    output = capfd.readouterr().err
    logs = parse_json_logs(output)

    assert response.headers["X-Request-ID"] == request_id
    assert any(
        item.get("event") == "request_completed"
        and item.get("request_id") == request_id
        for item in logs
    )


def test_invalid_request_id_is_replaced_and_not_logged(
    client: TestClient,
    capfd,
) -> None:
    invalid_request_id = "DEMO-DO-NOT-USE invalid"
    response = client.get(
        "/health",
        headers={"X-Request-ID": invalid_request_id},
    )
    output = capfd.readouterr().err

    assert REQUEST_ID_PATTERN.fullmatch(response.headers["X-Request-ID"])
    assert response.headers["X-Request-ID"] != invalid_request_id
    assert invalid_request_id not in output


def test_device_business_events_share_request_id(
    client: TestClient,
    capfd,
) -> None:
    capfd.readouterr()
    response = client.post(
        "/devices",
        json={
            "name": "Log Test Router",
            "device_type": "router",
            "ip_address": "192.168.80.1",
        },
        headers={"X-Request-ID": "registration-456"},
    )
    logs = parse_json_logs(capfd.readouterr().err)
    request_events = [item for item in logs if item.get("request_id") == "registration-456"]

    assert response.status_code == 201
    assert {
        item["event"]
        for item in request_events
        if item["event"] in {"device_registration_requested", "device_registered"}
    } == {"device_registration_requested", "device_registered"}
    assert all(item["logger"].startswith("netpulse.") for item in request_events)


def test_missing_device_emits_one_warning(client: TestClient, capfd) -> None:
    response = client.get(
        "/devices/00000000-0000-0000-0000-000000000001",
        headers={"X-Request-ID": "missing-device"},
    )
    logs = parse_json_logs(capfd.readouterr().err)
    warnings = [
        item for item in logs
        if item.get("request_id") == "missing-device" and item.get("level") == "warning"
    ]

    assert response.status_code == 404
    assert len(warnings) == 1
    assert warnings[0]["event"] == "device_not_found"
    assert warnings[0]["device_id"] == "00000000-0000-0000-0000-000000000001"


def test_duplicate_registration_emits_one_warning(client: TestClient, capfd) -> None:
    payload = {
        "name": "Duplicate Warning Test",
        "device_type": "switch",
        "ip_address": "192.168.80.2",
    }
    assert client.post("/devices", json=payload).status_code == 201
    capfd.readouterr()

    response = client.post(
        "/devices",
        json={**payload, "name": "Duplicate"},
        headers={"X-Request-ID": "duplicate-device"},
    )
    logs = parse_json_logs(capfd.readouterr().err)
    warnings = [
        item for item in logs
        if item.get("request_id") == "duplicate-device" and item.get("level") == "warning"
    ]

    assert response.status_code == 409
    assert len(warnings) == 1
    assert warnings[0]["event"] == "request_rejected"


def test_sensitive_fields_are_redacted_from_rendered_json(
    client: TestClient,
    capfd,
) -> None:
    logger = structlog.get_logger("netpulse.redaction_test")
    logger.info(
        "redaction_test",
        TOKEN="DEMO-DO-NOT-USE",
        Password="password-value",
        Api_Key="key-value",
        Authorization="auth-value",
        Secret="secret-value",
        safe_field="visible-value",
    )
    output = capfd.readouterr().err
    logs = parse_json_logs(output)

    assert "DEMO-DO-NOT-USE" not in output
    assert len(logs) == 1
    assert logs[0]["TOKEN"] == "***"
    assert logs[0]["Password"] == "***"
    assert logs[0]["Api_Key"] == "***"
    assert logs[0]["Authorization"] == "***"
    assert logs[0]["Secret"] == "***"
    assert logs[0]["safe_field"] == "visible-value"


def test_offline_alert_business_event_is_emitted_once(
    client: TestClient,
    capfd,
) -> None:
    device = client.post(
        "/devices",
        json={
            "name": "Alert Log Test",
            "device_type": "server",
            "ip_address": "192.168.80.3",
        },
    ).json()
    capfd.readouterr()
    endpoint = f"/devices/{device['device_id']}/status"

    first = client.patch(endpoint, json={"status": "offline"})
    second = client.patch(endpoint, json={"status": "offline"})
    logs = parse_json_logs(capfd.readouterr().err)
    alerts = [item for item in logs if item.get("event") == "offline_alert_created"]

    assert first.status_code == second.status_code == 200
    assert len(alerts) == 1
    assert alerts[0]["device_id"] == device["device_id"]


def test_unexpected_error_is_logged_once_and_keeps_request_id_header(
    database_engine: Engine,
    capfd,
) -> None:
    app = create_app(database_engine)

    def override_get_session(request):
        yield from get_session(request)

    def fail() -> None:
        raise RuntimeError("sensitive exception details should not be logged")

    app.dependency_overrides[get_session] = override_get_session
    app.add_api_route("/test-error", fail, methods=["GET"])
    capfd.readouterr()
    with TestClient(app, raise_server_exceptions=False) as test_client:
        response = test_client.get(
            "/test-error",
            headers={"X-Request-ID": "unexpected-789"},
        )
    output = capfd.readouterr().err
    logs = parse_json_logs(output)
    error_events = [
        item for item in logs
        if item.get("event") == "request_failed"
        and item.get("request_id") == "unexpected-789"
    ]
    completions = [
        item for item in logs
        if item.get("event") == "request_completed"
        and item.get("request_id") == "unexpected-789"
    ]

    assert response.status_code == 500
    assert response.text == "Internal Server Error"
    assert response.headers["X-Request-ID"] == "unexpected-789"
    assert len(error_events) == 1
    assert error_events[0]["exception_type"] == "RuntimeError"
    assert len(completions) == 1
    assert completions[0]["status_code"] == 500
    assert "sensitive exception details" not in output
