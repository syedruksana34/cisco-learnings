from collections.abc import Generator
from pathlib import Path

import pytest
from fastapi import Request
from fastapi.testclient import TestClient
from sqlalchemy import URL, create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from app.db.database import get_session
from app.main import create_app


@pytest.fixture
def database_engine(tmp_path: Path) -> Generator[Engine, None, None]:
    database_path = tmp_path / "netpulse_test.db"
    test_engine = create_engine(
        URL.create("sqlite", database=str(database_path)),
        connect_args={"check_same_thread": False},
    )
    yield test_engine
    test_engine.dispose()


@pytest.fixture
def client(database_engine: Engine) -> Generator[TestClient, None, None]:
    app = create_app(database_engine)

    def override_get_session(request: Request) -> Generator[Session, None, None]:
        yield from get_session(request)

    app.dependency_overrides[get_session] = override_get_session
    with TestClient(app) as test_client:
        yield test_client
