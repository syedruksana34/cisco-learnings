from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import uuid4

from sqlalchemy import URL, create_engine, select
from sqlalchemy.orm import Session

from app.db.database import Base
from app.db.models import DeviceRow


def main() -> None:
    with TemporaryDirectory(prefix="netpulse-crud-") as directory:
        database_path = Path(directory) / "crud_demo.db"
        demo_engine = create_engine(
            URL.create("sqlite", database=str(database_path)),
            connect_args={"check_same_thread": False},
        )
        try:
            Base.metadata.create_all(bind=demo_engine)
            with Session(demo_engine) as session:
                # Create
                device = DeviceRow(
                    device_id=str(uuid4()),
                    name="Demo Server",
                    device_type="server",
                    ip_address="192.0.2.10",
                    status="online",
                )
                session.add(device)
                session.commit()
                print(f"Created: {device.name}")

                # Read
                saved_device = session.scalar(
                    select(DeviceRow).where(DeviceRow.device_id == device.device_id)
                )
                print(f"Read: {saved_device.name if saved_device else 'not found'}")

                # Update
                if saved_device is not None:
                    saved_device.status = "offline"
                    session.commit()
                    print(f"Updated status: {saved_device.status}")

                # Delete
                if saved_device is not None:
                    session.delete(saved_device)
                    session.commit()
                    print("Deleted demo device")
        finally:
            demo_engine.dispose()


if __name__ == "__main__":
    main()
