export type DeviceStatus = 'online' | 'offline'

export type DeviceType = 'router' | 'switch' | 'server'

export interface Device {
  device_id: string
  name: string
  device_type: DeviceType
  ip_address: string
  status: DeviceStatus
}
