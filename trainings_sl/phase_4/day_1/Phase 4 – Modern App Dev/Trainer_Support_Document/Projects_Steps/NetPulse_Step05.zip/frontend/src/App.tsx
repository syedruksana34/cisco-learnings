import { useEffect, useState } from 'react'
import { getDevices } from './api/devices'
import type { Device } from './types/device'
import './App.css'

function App() {
  const [devices, setDevices] = useState<Device[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [reloadCount, setReloadCount] = useState(0)

  useEffect(() => {
    let isCurrent = true

    async function loadDevices() {
      setIsLoading(true)
      setError(null)

      try {
        const deviceList = await getDevices()
        if (isCurrent) {
          setDevices(deviceList)
        }
      } catch (requestError) {
        if (isCurrent) {
          setError(
            requestError instanceof Error
              ? requestError.message
              : 'Unable to load devices.',
          )
        }
      } finally {
        if (isCurrent) {
          setIsLoading(false)
        }
      }
    }

    void loadDevices()

    return () => {
      isCurrent = false
    }
  }, [reloadCount])

  const onlineCount = devices.filter((device) => device.status === 'online').length
  const offlineCount = devices.filter((device) => device.status === 'offline').length

  return (
    <main className="dashboard">
      <header className="page-header">
        <div className="brand-mark" aria-hidden="true">
          NP
        </div>
        <div>
          <h1>NetPulse</h1>
          <p>Network Monitoring Dashboard</p>
        </div>
      </header>

      <section className="summary-grid" aria-label="Device summary">
        <SummaryCard label="Total Devices" value={devices.length} accent="blue" />
        <SummaryCard label="Online Devices" value={onlineCount} accent="green" />
        <SummaryCard label="Offline Devices" value={offlineCount} accent="red" />
      </section>

      <section className="inventory-panel" aria-labelledby="inventory-title">
        <div className="inventory-heading">
          <div>
            <p className="eyebrow">OVERVIEW</p>
            <h2 id="inventory-title">Device Inventory</h2>
          </div>
          {!isLoading && !error && (
            <span className="device-count">
              {devices.length} {devices.length === 1 ? 'device' : 'devices'}
            </span>
          )}
        </div>

        {isLoading && (
          <div className="message-state" role="status">
            <span className="loading-spinner" aria-hidden="true" />
            Loading devices…
          </div>
        )}

        {error && (
          <div className="message-state error-state" role="alert">
            <div>
              <h3>Could not load devices</h3>
              <p>{error}</p>
              <p className="error-hint">
                Make sure the FastAPI backend is running at 127.0.0.1:8000.
              </p>
            </div>
            <button
              className="retry-button"
              type="button"
              onClick={() => setReloadCount((count) => count + 1)}
            >
              Try again
            </button>
          </div>
        )}

        {!isLoading && !error && devices.length === 0 && (
          <div className="message-state empty-state">
            <span className="empty-icon" aria-hidden="true">
              —
            </span>
            <h3>No devices yet</h3>
            <p>Devices registered with the NetPulse API will appear here.</p>
          </div>
        )}

        {!isLoading && !error && devices.length > 0 && (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th scope="col">Device ID</th>
                  <th scope="col">Device Name</th>
                  <th scope="col">Device Type</th>
                  <th scope="col">IP Address</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                {devices.map((device) => (
                  <tr key={device.device_id}>
                    <td className="device-id">{device.device_id}</td>
                    <td className="device-name">{device.name}</td>
                    <td>
                      <span className="type-label">{device.device_type}</span>
                    </td>
                    <td className="ip-address">{device.ip_address}</td>
                    <td>
                      <span className={`status-badge status-${device.status}`}>
                        <span className="status-dot" aria-hidden="true" />
                        {device.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <footer className="page-footer">
        <span>NetPulse monitoring</span>
        <span>Device data provided by the NetPulse API</span>
      </footer>
    </main>
  )
}

interface SummaryCardProps {
  label: string
  value: number
  accent: 'blue' | 'green' | 'red'
}

function SummaryCard({ label, value, accent }: SummaryCardProps) {
  return (
    <article className={`summary-card summary-${accent}`}>
      <p>{label}</p>
      <strong>{value}</strong>
      <span className="summary-indicator" aria-hidden="true" />
    </article>
  )
}

export default App
