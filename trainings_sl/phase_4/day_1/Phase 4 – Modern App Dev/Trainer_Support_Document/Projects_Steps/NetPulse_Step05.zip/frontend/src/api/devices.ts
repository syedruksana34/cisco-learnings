import type { Device } from '../types/device'

export async function getDevices(): Promise<Device[]> {
  const response = await fetch('/api/devices')

  if (!response.ok) {
    throw new Error(`The API returned an error (${response.status}).`)
  }

  return (await response.json()) as Device[]
}
