from ipaddress import IPv4Address
from typing import Protocol

from app.events import DeviceOfflineAlert
from app.models import Device, DeviceStatus, DeviceType


class DeviceRepository(Protocol):
    def add(self, device: Device) -> Device: ...

    def get(self, device_id: str) -> Device | None: ...

    def get_by_ip(self, ip_address: IPv4Address) -> Device | None: ...

    def list_all(
        self,
        status: DeviceStatus | None = None,
        device_type: DeviceType | None = None,
        search: str | None = None,
        limit: int | None = None,
        offset: int = 0,
    ) -> list[Device]: ...

    def update(self, device: Device) -> Device: ...

    def add_alert(self, alert: DeviceOfflineAlert) -> None: ...

    def list_alerts(self) -> list[DeviceOfflineAlert]: ...


class InMemoryDeviceRepository:
    def __init__(self) -> None:
        self._devices: dict[str, Device] = {}
        self._alerts: list[DeviceOfflineAlert] = []

    def add(self, device: Device) -> Device:
        self._devices[device.device_id] = device
        return device

    def get(self, device_id: str) -> Device | None:
        return self._devices.get(device_id)

    def get_by_ip(self, ip_address: IPv4Address) -> Device | None:
        return next(
            (device for device in self._devices.values() if device.ip_address == ip_address),
            None,
        )

    def list_all(
        self,
        status: DeviceStatus | None = None,
        device_type: DeviceType | None = None,
        search: str | None = None,
        limit: int | None = None,
        offset: int = 0,
    ) -> list[Device]:
        devices = sorted(self._devices.values(), key=lambda device: device.device_id)
        if status is not None:
            devices = [device for device in devices if device.status == status]
        if device_type is not None:
            devices = [device for device in devices if device.device_type == device_type]
        if search is not None:
            term = search.casefold()
            devices = [
                device
                for device in devices
                if term in device.name.casefold() or term in str(device.ip_address).casefold()
            ]
        return devices[offset:] if limit is None else devices[offset : offset + limit]

    def update(self, device: Device) -> Device:
        self._devices[device.device_id] = device
        return device

    def add_alert(self, alert: DeviceOfflineAlert) -> None:
        self._alerts.append(alert)

    def list_alerts(self) -> list[DeviceOfflineAlert]:
        return list(self._alerts)
