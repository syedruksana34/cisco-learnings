from datetime import timezone
from ipaddress import IPv4Address
from uuid import UUID

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.events import DeviceOfflineAlert
from app.models import Device, DeviceStatus, DeviceType
from app.db.models import AlertRow, DeviceRow


class SQLAlchemyDeviceRepository:
    def __init__(self, session: Session) -> None:
        self._session = session

    def add(self, device: Device) -> Device:
        row = DeviceRow(
            device_id=device.device_id,
            name=device.name,
            device_type=device.device_type.value,
            ip_address=str(device.ip_address),
            status=device.status.value,
        )
        self._session.add(row)
        self._session.flush()
        return device

    def get(self, device_id: str) -> Device | None:
        row = self._session.get(DeviceRow, device_id)
        return self._to_device(row) if row is not None else None

    def get_by_ip(self, ip_address: IPv4Address) -> Device | None:
        row = self._session.scalar(
            select(DeviceRow).where(DeviceRow.ip_address == str(ip_address))
        )
        return self._to_device(row) if row is not None else None

    def list_all(
        self,
        status: DeviceStatus | None = None,
        device_type: DeviceType | None = None,
        search: str | None = None,
        limit: int | None = None,
        offset: int = 0,
    ) -> list[Device]:
        statement = select(DeviceRow)
        if status is not None:
            statement = statement.where(DeviceRow.status == status.value)
        if device_type is not None:
            statement = statement.where(DeviceRow.device_type == device_type.value)
        if search is not None:
            escaped_search = (
                search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            pattern = f"%{escaped_search}%"
            statement = statement.where(
                or_(
                    DeviceRow.name.ilike(pattern, escape="\\"),
                    DeviceRow.ip_address.ilike(pattern, escape="\\"),
                )
            )
        statement = statement.order_by(DeviceRow.device_id)
        if limit is not None:
            statement = statement.limit(limit)
        if offset:
            statement = statement.offset(offset)
        rows = self._session.scalars(statement).all()
        return [self._to_device(row) for row in rows]

    def update(self, device: Device) -> Device:
        row = self._session.get(DeviceRow, device.device_id)
        if row is None:
            raise LookupError(f"Device {device.device_id} does not exist")

        row.name = device.name
        row.device_type = device.device_type.value
        row.ip_address = str(device.ip_address)
        row.status = device.status.value
        self._session.flush()
        return self._to_device(row)

    def add_alert(self, alert: DeviceOfflineAlert) -> None:
        row = AlertRow(
            alert_id=str(alert.alert_id),
            device_id=str(alert.device_id),
            message=alert.message,
            timestamp=alert.created_at,
        )
        self._session.add(row)
        self._session.flush()

    def list_alerts(self) -> list[DeviceOfflineAlert]:
        rows = self._session.scalars(select(AlertRow).order_by(AlertRow.id)).all()
        return [self._to_alert(row) for row in rows]

    @staticmethod
    def _to_device(row: DeviceRow) -> Device:
        return Device(
            device_id=row.device_id,
            name=row.name,
            device_type=DeviceType(row.device_type),
            ip_address=IPv4Address(row.ip_address),
            status=DeviceStatus(row.status),
        )

    @staticmethod
    def _to_alert(row: AlertRow) -> DeviceOfflineAlert:
        created_at = row.timestamp
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)
        return DeviceOfflineAlert(
            alert_id=UUID(row.alert_id),
            device_id=row.device_id,
            message=row.message,
            created_at=created_at,
        )
