from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.dependencies import get_device_service
from app.events import DeviceOfflineAlert
from app.models import (
    Device,
    DeviceCreate,
    DeviceStatus,
    DeviceStatusUpdate,
    DeviceSummary,
    DeviceType,
    ProbeResponse,
)
from app.services.device_service import DeviceService

router = APIRouter()

ServiceDependency = Annotated[DeviceService, Depends(get_device_service)]


@router.post("/devices", response_model=Device, status_code=status.HTTP_201_CREATED)
def register_device(
    payload: DeviceCreate,
    service: ServiceDependency,
) -> Device:
    try:
        return service.register_device(payload)
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(error),
        ) from error


@router.get("/devices", response_model=list[Device])
def list_devices(
    service: ServiceDependency,
    status_filter: DeviceStatus | None = Query(default=None, alias="status"),
    device_type: DeviceType | None = None,
    search: str | None = None,
    limit: int | None = Query(default=None, ge=1, le=100),
    offset: int | None = Query(default=None, ge=0),
) -> list[Device]:
    return service.list_devices(
        status=status_filter,
        device_type=device_type,
        search=search,
        limit=limit,
        offset=offset,
    )


@router.get("/devices/summary", response_model=DeviceSummary)
def get_device_summary(service: ServiceDependency) -> DeviceSummary:
    return service.get_summary()


@router.get("/devices/{device_id}/probe", response_model=ProbeResponse)
def probe_device(device_id: str, service: ServiceDependency) -> ProbeResponse:
    result = service.probe_device(device_id)
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found",
        )
    return result


@router.get("/devices/{device_id}", response_model=Device)
def get_device(device_id: str, service: ServiceDependency) -> Device:
    device = service.get_device(device_id)
    if device is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found",
        )
    return device


@router.patch("/devices/{device_id}/status", response_model=Device)
def update_device_status(
    device_id: str,
    payload: DeviceStatusUpdate,
    service: ServiceDependency,
) -> Device:
    device = service.update_device_status(device_id, payload.status)
    if device is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found",
        )
    return device


@router.get("/alerts", response_model=list[DeviceOfflineAlert])
def list_alerts(service: ServiceDependency) -> list[DeviceOfflineAlert]:
    return service.list_alerts()
