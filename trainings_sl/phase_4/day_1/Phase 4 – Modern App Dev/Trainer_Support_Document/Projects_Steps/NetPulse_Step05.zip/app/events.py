from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class DeviceOfflineAlert(BaseModel):
    alert_id: UUID
    device_id: str
    message: str
    created_at: datetime
