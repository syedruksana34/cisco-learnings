from pathlib import Path

from sqlalchemy.orm import Session

from app.db.database import SessionLocal, engine
from app.db.models import DeviceRow
from app.models import Device, DeviceCreate, DeviceStatus, DeviceType
from app.repositories.sqlalchemy_device_repository import SQLAlchemyDeviceRepository

SEED_DEVICES: tuple[tuple[DeviceCreate, DeviceStatus], ...] = (
    (
        DeviceCreate(
            device_id="RTR-101",
            name="Chennai-Core-Router",
            device_type=DeviceType.ROUTER,
            ip_address="10.250.101.1",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="RTR-102",
            name="Bengaluru-Edge-Router",
            device_type=DeviceType.ROUTER,
            ip_address="10.250.101.2",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="RTR-103",
            name="Hyderabad-Branch-Router",
            device_type=DeviceType.ROUTER,
            ip_address="10.250.101.3",
        ),
        DeviceStatus.OFFLINE,
    ),
    (
        DeviceCreate(
            device_id="RTR-104",
            name="Chennai-WAN-Router",
            device_type=DeviceType.ROUTER,
            ip_address="10.250.101.4",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="RTR-105",
            name="Bengaluru-Backup-Router",
            device_type=DeviceType.ROUTER,
            ip_address="10.250.101.5",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="SWT-201",
            name="Chennai-Access-Switch",
            device_type=DeviceType.SWITCH,
            ip_address="10.250.102.1",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="SWT-202",
            name="Bengaluru-Core-Switch",
            device_type=DeviceType.SWITCH,
            ip_address="10.250.102.2",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="SWT-203",
            name="Hyderabad-Floor-Switch",
            device_type=DeviceType.SWITCH,
            ip_address="10.250.102.3",
        ),
        DeviceStatus.OFFLINE,
    ),
    (
        DeviceCreate(
            device_id="SWT-204",
            name="Chennai-Distribution-Switch",
            device_type=DeviceType.SWITCH,
            ip_address="10.250.102.4",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="SWT-205",
            name="Bengaluru-Lab-Switch",
            device_type=DeviceType.SWITCH,
            ip_address="10.250.102.5",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="SRV-301",
            name="Chennai-App-Server",
            device_type=DeviceType.SERVER,
            ip_address="10.250.103.1",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="SRV-302",
            name="Bengaluru-Database-Server",
            device_type=DeviceType.SERVER,
            ip_address="10.250.103.2",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="SRV-303",
            name="Hyderabad-Web-Server",
            device_type=DeviceType.SERVER,
            ip_address="10.250.103.3",
        ),
        DeviceStatus.OFFLINE,
    ),
    (
        DeviceCreate(
            device_id="SRV-304",
            name="Chennai-Monitoring-Server",
            device_type=DeviceType.SERVER,
            ip_address="10.250.103.4",
        ),
        DeviceStatus.ONLINE,
    ),
    (
        DeviceCreate(
            device_id="SRV-305",
            name="Bengaluru-Backup-Server",
            device_type=DeviceType.SERVER,
            ip_address="10.250.103.5",
        ),
        DeviceStatus.OFFLINE,
    ),
)


def _configured_database_path() -> Path:
    database = engine.url.database
    if engine.url.get_backend_name() != "sqlite" or database in (None, "", ":memory:"):
        raise RuntimeError("The seed script requires a file-backed SQLite database")
    return Path(database).resolve()


def seed_devices(session: Session) -> tuple[int, int]:
    repository = SQLAlchemyDeviceRepository(session)
    inserted = 0
    skipped = 0

    for payload, device_status in SEED_DEVICES:
        if session.get(DeviceRow, payload.device_id) is not None:
            skipped += 1
            continue

        existing_ip_device = repository.get_by_ip(payload.ip_address)
        if existing_ip_device is not None:
            raise ValueError(
                f"Seed IP address {payload.ip_address} is already assigned "
                f"to device {existing_ip_device.device_id}"
            )

        device = Device(
            **payload.model_dump(),
            status=device_status,
        )
        repository.add(device)
        inserted += 1

    return inserted, skipped


def main() -> None:
    database_path = _configured_database_path()
    with SessionLocal.begin() as session:
        inserted, skipped = seed_devices(session)

    print(f"Database: {database_path}")
    print(f"Inserted: {inserted}")
    print(f"Skipped (device_id already exists): {skipped}")


if __name__ == "__main__":
    main()
