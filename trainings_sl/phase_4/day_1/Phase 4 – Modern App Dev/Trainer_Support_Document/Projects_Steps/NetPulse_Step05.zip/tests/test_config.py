import pytest
from pydantic import ValidationError

from app.config import DEFAULT_PAGE_SIZE, Settings, settings


def test_default_settings_preserve_database_and_page_size(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    for variable in ("APP_NAME", "LOG_LEVEL", "DATABASE_URL", "DEFAULT_PAGE_SIZE"):
        monkeypatch.delenv(variable, raising=False)

    defaults = Settings(_env_file=None)

    assert defaults.database_url == "sqlite:///./netpulse.db"
    assert defaults.default_page_size == 20
    assert DEFAULT_PAGE_SIZE == settings.default_page_size


def test_settings_read_environment_overrides(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("APP_NAME", "NetPulse Training")
    monkeypatch.setenv("LOG_LEVEL", "DEBUG")
    monkeypatch.setenv("DATABASE_URL", "sqlite:///./training.db")
    monkeypatch.setenv("DEFAULT_PAGE_SIZE", "15")

    configured = Settings(_env_file=None)

    assert configured.app_name == "NetPulse Training"
    assert configured.log_level == "DEBUG"
    assert configured.database_url == "sqlite:///./training.db"
    assert configured.default_page_size == 15


def test_settings_reject_non_sqlite_database_urls() -> None:
    with pytest.raises(ValidationError):
        Settings(database_url="postgresql://localhost/netpulse")
