from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import NAMESPACE_URL, UUID, uuid5

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.database import SessionLocal, engine
from app.db.models import AlertRow, DeviceRow

SEED_ALERTS: tuple[tuple[UUID, str, str, int], ...] = (
    (
        uuid5(NAMESPACE_URL, "netpulse-local-demo-alerts:RTR-103:first"),
        "RTR-103",
        "Demo alert: Hyderabad branch router went offline",
        45,
    ),
    (
        uuid5(NAMESPACE_URL, "netpulse-local-demo-alerts:RTR-103:repeat"),
        "RTR-103",
        "Demo alert: Hyderabad branch router remains offline",
        5,
    ),
    (
        uuid5(NAMESPACE_URL, "netpulse-local-demo-alerts:SRV-303"),
        "SRV-303",
        "Demo alert: Hyderabad web server is offline",
        18,
    ),
    (
        uuid5(NAMESPACE_URL, "netpulse-local-demo-alerts:SWT-203"),
        "SWT-203",
        "Demo alert: Hyderabad floor switch is offline",
        30,
    ),
)


def _configured_database_path() -> Path:
    database = engine.url.database
    if engine.url.get_backend_name() != "sqlite" or database in (None, "", ":memory:"):
        raise RuntimeError("The alert seed script requires a file-backed SQLite database")
    return Path(database).resolve()


def seed_alerts(session: Session) -> tuple[int, int]:
    target_device_ids = {device_id for _, device_id, _, _ in SEED_ALERTS}
    existing_device_ids = set(
        session.scalars(
            select(DeviceRow.device_id).where(
                DeviceRow.device_id.in_(target_device_ids)
            )
        ).all()
    )
    missing_device_ids = sorted(target_device_ids - existing_device_ids)
    if missing_device_ids:
        raise ValueError(
            "Cannot seed alerts; target devices are missing: "
            + ", ".join(missing_device_ids)
        )

    seed_alert_ids = [str(alert_id) for alert_id, _, _, _ in SEED_ALERTS]
    existing_alerts = {
        row.alert_id: row
        for row in session.scalars(
            select(AlertRow).where(AlertRow.alert_id.in_(seed_alert_ids))
        ).all()
    }

    inserted = 0
    skipped = 0
    seeded_at = datetime.now(timezone.utc)
    for alert_id, device_id, message, minutes_ago in SEED_ALERTS:
        alert_id_value = str(alert_id)
        existing_alert = existing_alerts.get(alert_id_value)
        if existing_alert is not None:
            if (
                existing_alert.device_id != device_id
                or existing_alert.message != message
            ):
                raise ValueError(
                    f"Seed alert ID {alert_id_value} is already used by another alert"
                )
            skipped += 1
            continue

        session.add(
            AlertRow(
                alert_id=alert_id_value,
                device_id=device_id,
                message=message,
                timestamp=seeded_at - timedelta(minutes=minutes_ago),
            )
        )
        inserted += 1

    session.flush()
    return inserted, skipped


def main() -> None:
    database_path = _configured_database_path()
    with SessionLocal.begin() as session:
        inserted, skipped = seed_alerts(session)

    print(f"Database: {database_path}")
    print(f"Inserted: {inserted}")
    print(f"Skipped (seed alert already exists): {skipped}")


if __name__ == "__main__":
    main()
