# NetPulse

NetPulse is a beginner-friendly network device monitoring API built with FastAPI.
It uses SQLite with SQLAlchemy 2.x; registered devices and alerts persist when
the application restarts.

## Requirements

- Python 3.11 or newer
- SQLite (included with Python)

## Setup (Windows PowerShell)

From the project root:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell prevents environment activation, run the commands below using the
virtual environment's interpreter directly:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

The application creates `netpulse.db` in the current working directory on
startup. The file is local application data and is ignored by Git.

## Run the API

```powershell
python -m uvicorn app.main:app --reload --port 8001
```

Open `http://127.0.0.1:8001/docs` to try the API. The health endpoint is
available at `http://127.0.0.1:8001/health`.

## Run the React dashboard

Start the FastAPI backend in one terminal from the project root:

```powershell
python -m uvicorn app.main:app --reload --port 8001
```

In another terminal, install the frontend packages and start Vite:

```powershell
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. The dashboard fetches the complete device list
from `/api/devices`; Vite proxies that request to the existing
`http://127.0.0.1:8001/devices` endpoint. This keeps local browser requests
same-origin and does not require adding backend CORS middleware.
If the backend is listening on another local port, set `NETPULSE_API_URL`
before starting Vite to point the proxy at that URL; the default is
`http://127.0.0.1:8001`.

The dashboard search matches device names case-insensitively and IP addresses
by substring. Status and device-type filters can be combined with search and
are applied by the backend. Use **Clear Filters** to restore the full list;
summary cards continue to count the full inventory.

The Device Analytics and Alert Analytics sections read their summaries from
`/api/analytics/devices`. When there are no alerts, the dashboard shows zero
counts and empty states instead of sample alert data.

To create a production build of the frontend:

```powershell
cd frontend
npm run build
```

## Run tests

```powershell
python -m pytest -q
```

Tests use isolated SQLite files under pytest's temporary directory; they do not
read or modify the local `netpulse.db`.

## Seed local development devices

Seed data gives the dashboard and API a realistic device inventory to work
with during local development. From the project root, run:

```powershell
python -m scripts.seed_devices
```

The script uses the configured SQLite database, inserts the 15 sample devices
only when their IDs are missing, and preserves all existing records without
changing their fields. It is intended for local development.

## Seed local development alerts

To populate the Alert Analytics dashboard with repeatable demonstration data,
run this from the project root:

```powershell
python -m scripts.seed_alerts
```

The script adds four alerts for existing offline devices, including two alerts
for `RTR-103` so repeated-alert analytics are visible. Stable alert IDs make
reruns skip those rows; existing alerts and device records are preserved. This
is intended for local development.

## Environment settings

The application reads optional environment overrides (or values in a local
`.env` file) for:

| Variable | Default | Description |
| --- | --- | --- |
| `APP_NAME` | `NetPulse API` | FastAPI application title |
| `LOG_LEVEL` | `INFO` | `DEBUG`, `INFO`, `WARNING`, `ERROR`, or `CRITICAL` |
| `DATABASE_URL` | `sqlite:///./netpulse.db` | SQLite database URL; the default keeps the existing database path |
| `DEFAULT_PAGE_SIZE` | `20` | Page size used when only `offset` is provided (1–100) |

For example, create an ignored `.env` file in the project root:

```dotenv
APP_NAME=NetPulse API
LOG_LEVEL=INFO
DATABASE_URL=sqlite:///./netpulse.db
DEFAULT_PAGE_SIZE=20
```

`DATABASE_URL` must use SQLite. Keep connection URLs and credentials out of
application logs.

## Device list filtering, search, and pagination

`GET /devices` always returns a JSON list. Optional filters can be combined:

- `status`: `online` or `offline`
- `device_type`: `router`, `switch`, or `server`
- `search`: case-insensitive substring in device names or substring in IP addresses

Search treats `%` and `_` as literal characters, not SQL wildcard operators.
Queries use bound SQLAlchemy expressions and escape the literal pattern
characters.

Pagination is deterministic by ascending `device_id` and is applied after
filtering:

- Without `limit` or `offset`, every matching device is returned.
- With `limit`, that limit is used; an omitted `offset` defaults to `0`.
- With `offset` alone, the configured `DEFAULT_PAGE_SIZE` is used.
- `limit` must be 1–100 and `offset` must be non-negative. Invalid values
  receive HTTP 422.

Examples:

```text
GET /devices
GET /devices?status=offline
GET /devices?device_type=router
GET /devices?search=Cisco
GET /devices?search=192.168
GET /devices?status=online&device_type=router&search=Cisco
GET /devices?limit=2
GET /devices?limit=2&offset=0
GET /devices?limit=2&offset=2
GET /devices?offset=2
```

### Sample walkthrough

The following valid `POST /devices` JSON bodies use the existing device schema.
Before creating a device, check `GET /devices/{device_id}` and reuse it if it
already exists; this avoids duplicate IDs and preserves existing records.

```json
{
  "device_id": "FLT-601",
  "name": "Cisco-Core-Router",
  "device_type": "router",
  "ip_address": "192.168.60.1"
}
```

```json
{
  "device_id": "FLT-602",
  "name": "Cisco-Edge-Switch",
  "device_type": "switch",
  "ip_address": "10.20.60.2"
}
```

```json
{
  "device_id": "FLT-603",
  "name": "Branch-Server",
  "device_type": "server",
  "ip_address": "192.168.60.3"
}
```

```json
{
  "device_id": "FLT-604",
  "name": "Office-Router",
  "device_type": "router",
  "ip_address": "10.20.60.4"
}
```

```json
{
  "device_id": "FLT-605",
  "name": "Lab-Switch",
  "device_type": "switch",
  "ip_address": "172.16.60.5"
}
```

After adding or reusing those devices, set `FLT-604` offline with:

```http
PATCH /devices/FLT-604/status
Content-Type: application/json

{"status":"offline"}
```

Try the examples above to verify filters and pagination. The simulated probe
uses `GET /devices/{device_id}/probe`; it does not change device status.

## API endpoints

- `POST /devices` — register a router, switch, or server
- `GET /devices` — list, filter, search, or paginate registered devices
- `GET /devices/summary` — aggregate device and status counts
- `GET /devices/{device_id}` — retrieve one device
- `PATCH /devices/{device_id}/status` — set a device to online or offline
- `GET /devices/{device_id}/probe` — return a deterministic simulated probe result
- `GET /alerts` — list alerts generated when a device goes offline
- `GET /health` — API health check

`POST /devices` requires `device_id`, `name`, `device_type`, and an IPv4
`ip_address`. It returns HTTP 201 when registered, HTTP 409 when the device ID
or IP address already exists, and HTTP 422 when request fields are invalid.

The simulated probe does not contact the network or change device status. Its
deterministic rule uses the final IPv4 octet: even means `reachable`; odd means
`unreachable`.

## FastAPI, ASGI, and database sessions

FastAPI is an ASGI web framework. Uvicorn is an ASGI server that runs the
application and handles HTTP connections. Traditional WSGI servers use a
synchronous interface intended for frameworks such as Flask; ASGI additionally
supports asynchronous request handling and long-lived connections.

NetPulse currently uses synchronous SQLAlchemy sessions and synchronous route
handlers. FastAPI runs synchronous handlers and dependencies in a worker
threadpool, which keeps blocking database work off the event loop. Each request
gets its own session, which is committed on success and rolled back on errors.
SQLite's `check_same_thread=False` allows connections to be used across the
request's worker-thread handoff; sessions themselves should not be shared
between concurrent requests or tasks.

## SQLite CRUD example

Run the isolated CRUD demonstration with:

```powershell
python -m examples.sqlite_crud_demo
```

It creates a separate temporary database and removes it when the script exits;
it does not touch `netpulse.db`.

## Structured logging and request IDs

NetPulse configures structlog once during application startup. Application
events are emitted as one JSON object per line to stderr using the named
`netpulse` logger hierarchy. Uvicorn's startup and access logger configuration
is left unchanged.

For example, a completed request is logged with fields like:

```json
{"event":"request_completed","level":"info","logger":"netpulse.request","timestamp":"2026-11-21T07:39:00.000Z","request_id":"a1b2c3","method":"GET","path":"/health","status_code":200,"duration_ms":1.25}
```

Send an optional request ID with `X-Request-ID`. NetPulse accepts only 1–64
letters, digits, underscores, or hyphens; invalid or missing values are
replaced with a generated ID. The response includes the selected value in the
same header. `request_id` correlates log events for one HTTP request;
`device_id` identifies a stored device and remains stable across requests.

Application logs use `INFO` for lifecycle and business events, `WARNING` for
missing devices and handled conflicts, and `ERROR` for unexpected request
exceptions. Request completion records include the method, path without query
parameters, status code, request ID, and elapsed time.

Sensitive top-level fields named `password`, `token`, `api_key`,
`authorization`, or `secret` (case-insensitive) are replaced with `***` before
rendering. Do not log request bodies, authorization headers, credentials, or
connection strings. This simple processor does not recursively sanitize
nested objects, so avoid placing sensitive data inside nested values.

When running from VS Code, inspect the integrated Terminal where Uvicorn is
running; application JSON events are written to stderr. The existing SQLite,
request-scoped synchronous SQLAlchemy session, and ASGI/Uvicorn behavior
described above are unchanged.
