from datetime import datetime
from enum import Enum
from ipaddress import IPv4Address
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class DeviceType(str, Enum):
    ROUTER = "router"
    SWITCH = "switch"
    SERVER = "server"


class DeviceStatus(str, Enum):
    ONLINE = "online"
    OFFLINE = "offline"


class DeviceCreate(BaseModel):
    device_id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    device_type: DeviceType
    ip_address: IPv4Address


class DeviceStatusUpdate(BaseModel):
    status: DeviceStatus


class Device(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    device_id: str
    name: str
    device_type: DeviceType
    ip_address: IPv4Address
    status: DeviceStatus = DeviceStatus.ONLINE


class DeviceSummary(BaseModel):
    total_devices: int
    online_devices: int
    offline_devices: int
    router_count: int
    switch_count: int
    server_count: int


class ProbeResponse(BaseModel):
    device_id: str
    result: Literal["reachable", "unreachable"]
    simulated: bool


class AnalyticsDeviceSummary(BaseModel):
    total_devices: int
    online_devices: int
    offline_devices: int


class DeviceTypeStatistics(BaseModel):
    device_type: DeviceType
    total_devices: int
    online_devices: int
    offline_devices: int


class AlertCountByDevice(BaseModel):
    device_id: str
    name: str
    alert_count: int


class AnalyticsAlertSummary(BaseModel):
    total_alerts: int
    alert_counts_by_device: list[AlertCountByDevice]


class LatestDeviceAlert(BaseModel):
    alert_id: UUID
    device_id: str
    device_name: str
    message: str
    timestamp: datetime


class DeviceAnalyticsResponse(BaseModel):
    device_summary: AnalyticsDeviceSummary
    device_type_statistics: list[DeviceTypeStatistics]
    alert_summary: AnalyticsAlertSummary
    repeated_alert_devices: list[AlertCountByDevice]
    latest_alerts: list[LatestDeviceAlert]
