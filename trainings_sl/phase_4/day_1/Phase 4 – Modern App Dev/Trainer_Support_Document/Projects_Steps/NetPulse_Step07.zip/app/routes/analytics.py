from typing import Annotated

from fastapi import APIRouter, Depends

from app.dependencies import get_analytics_service
from app.models import DeviceAnalyticsResponse
from app.services.analytics_service import AnalyticsService

router = APIRouter()

AnalyticsServiceDependency = Annotated[
    AnalyticsService,
    Depends(get_analytics_service),
]


@router.get("/analytics/devices", response_model=DeviceAnalyticsResponse)
def get_device_analytics(
    service: AnalyticsServiceDependency,
) -> DeviceAnalyticsResponse:
    return service.get_device_analytics()
