from datetime import datetime, timezone

from sqlalchemy import and_, case, func, or_, select
from sqlalchemy.orm import Session

from app.db.models import AlertRow, DeviceRow
from app.models import (
    AlertCountByDevice,
    AnalyticsAlertSummary,
    AnalyticsDeviceSummary,
    DeviceAnalyticsResponse,
    DeviceStatus,
    DeviceType,
    DeviceTypeStatistics,
    LatestDeviceAlert,
)


class SQLAlchemyAnalyticsRepository:
    def __init__(self, session: Session) -> None:
        self._session = session

    def get_device_analytics(self) -> DeviceAnalyticsResponse:
        summary_row = self._session.execute(
            select(
                func.count(DeviceRow.device_id).label("total_devices"),
                func.count(
                    case(
                        (DeviceRow.status == DeviceStatus.ONLINE.value, DeviceRow.device_id),
                    )
                ).label("online_devices"),
                func.count(
                    case(
                        (DeviceRow.status == DeviceStatus.OFFLINE.value, DeviceRow.device_id),
                    )
                ).label("offline_devices"),
            )
        ).one()
        device_summary = AnalyticsDeviceSummary(
            total_devices=summary_row.total_devices,
            online_devices=summary_row.online_devices,
            offline_devices=summary_row.offline_devices,
        )

        known_device_types = tuple(device_type.value for device_type in DeviceType)
        type_rows = self._session.execute(
            select(
                DeviceRow.device_type,
                func.count(DeviceRow.device_id).label("total_devices"),
                func.count(
                    case(
                        (DeviceRow.status == DeviceStatus.ONLINE.value, DeviceRow.device_id),
                    )
                ).label("online_devices"),
                func.count(
                    case(
                        (DeviceRow.status == DeviceStatus.OFFLINE.value, DeviceRow.device_id),
                    )
                ).label("offline_devices"),
            )
            .where(
                and_(
                    or_(*(DeviceRow.device_type == value for value in known_device_types)),
                    or_(
                        DeviceRow.status == DeviceStatus.ONLINE.value,
                        DeviceRow.status == DeviceStatus.OFFLINE.value,
                    ),
                )
            )
            .group_by(DeviceRow.device_type)
            .order_by(DeviceRow.device_type)
        ).all()
        statistics_by_type = {
            row.device_type: DeviceTypeStatistics(
                device_type=DeviceType(row.device_type),
                total_devices=row.total_devices,
                online_devices=row.online_devices,
                offline_devices=row.offline_devices,
            )
            for row in type_rows
        }
        device_type_statistics = [
            statistics_by_type.get(
                device_type.value,
                DeviceTypeStatistics(
                    device_type=device_type,
                    total_devices=0,
                    online_devices=0,
                    offline_devices=0,
                ),
            )
            for device_type in DeviceType
        ]

        alert_count = func.count(AlertRow.id)
        alert_count_rows = self._session.execute(
            select(
                DeviceRow.device_id,
                DeviceRow.name,
                alert_count.label("alert_count"),
            )
            .outerjoin(
                AlertRow,
                and_(
                    DeviceRow.device_id == AlertRow.device_id,
                    AlertRow.timestamp.is_not(None),
                ),
            )
            .group_by(DeviceRow.device_id, DeviceRow.name)
            .order_by(DeviceRow.device_id)
        ).all()
        alert_counts_by_device = [
            AlertCountByDevice(
                device_id=row.device_id,
                name=row.name,
                alert_count=row.alert_count,
            )
            for row in alert_count_rows
        ]

        repeated_rows = self._session.execute(
            select(
                DeviceRow.device_id,
                DeviceRow.name,
                alert_count.label("alert_count"),
            )
            .join(
                AlertRow,
                and_(
                    DeviceRow.device_id == AlertRow.device_id,
                    AlertRow.timestamp.is_not(None),
                ),
            )
            .group_by(DeviceRow.device_id, DeviceRow.name)
            .having(alert_count > 1)
            .order_by(alert_count.desc(), DeviceRow.device_id)
        ).all()
        repeated_alert_devices = [
            AlertCountByDevice(
                device_id=row.device_id,
                name=row.name,
                alert_count=row.alert_count,
            )
            for row in repeated_rows
        ]

        ranked_alerts = (
            select(
                AlertRow.id.label("id"),
                AlertRow.alert_id.label("alert_id"),
                AlertRow.device_id.label("device_id"),
                AlertRow.message.label("message"),
                AlertRow.timestamp.label("timestamp"),
                func.row_number()
                .over(
                    partition_by=AlertRow.device_id,
                    order_by=(AlertRow.timestamp.desc(), AlertRow.id.desc()),
                )
                .label("position"),
            )
            .subquery("ranked_alerts")
        )
        latest_rows = self._session.execute(
            select(
                ranked_alerts.c.alert_id,
                ranked_alerts.c.device_id,
                DeviceRow.name.label("device_name"),
                ranked_alerts.c.message,
                ranked_alerts.c.timestamp,
            )
            .join(
                DeviceRow,
                and_(
                    DeviceRow.device_id == ranked_alerts.c.device_id,
                    ranked_alerts.c.position == 1,
                ),
            )
            .order_by(ranked_alerts.c.timestamp.desc(), DeviceRow.device_id)
        ).all()
        latest_alerts = [
            LatestDeviceAlert(
                alert_id=row.alert_id,
                device_id=row.device_id,
                device_name=row.device_name,
                message=row.message,
                timestamp=self._as_utc(row.timestamp),
            )
            for row in latest_rows
        ]

        total_alerts = self._session.scalar(select(func.count(AlertRow.id))) or 0
        return DeviceAnalyticsResponse(
            device_summary=device_summary,
            device_type_statistics=device_type_statistics,
            alert_summary=AnalyticsAlertSummary(
                total_alerts=total_alerts,
                alert_counts_by_device=alert_counts_by_device,
            ),
            repeated_alert_devices=repeated_alert_devices,
            latest_alerts=latest_alerts,
        )

    @staticmethod
    def _as_utc(value: datetime) -> datetime:
        return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value
