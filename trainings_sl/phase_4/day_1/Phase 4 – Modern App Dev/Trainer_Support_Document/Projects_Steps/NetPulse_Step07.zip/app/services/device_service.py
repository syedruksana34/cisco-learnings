from datetime import datetime, timezone
from uuid import uuid4

import structlog

from app.config import DEFAULT_PAGE_SIZE
from app.events import DeviceOfflineAlert
from app.models import (
    Device,
    DeviceCreate,
    DeviceStatus,
    DeviceSummary,
    DeviceType,
    ProbeResponse,
)
from app.repositories.device_repository import DeviceRepository

logger = structlog.get_logger("netpulse.devices")


class DeviceService:
    def __init__(self, repository: DeviceRepository) -> None:
        self._repository = repository

    def register_device(self, payload: DeviceCreate) -> Device:
        logger.info(
            "device_registration_requested",
            device_type=payload.device_type.value,
        )
        if self._repository.get(payload.device_id) is not None:
            raise ValueError(f"A device with ID {payload.device_id} already exists")
        if self._repository.get_by_ip(payload.ip_address) is not None:
            raise ValueError(f"A device with IP address {payload.ip_address} already exists")

        device = Device(
            device_id=payload.device_id,
            name=payload.name,
            device_type=payload.device_type,
            ip_address=payload.ip_address,
        )
        registered_device = self._repository.add(device)
        logger.info(
            "device_registered",
            device_id=str(registered_device.device_id),
            device_type=registered_device.device_type.value,
        )
        return registered_device

    def list_devices(
        self,
        status: DeviceStatus | None = None,
        device_type: DeviceType | None = None,
        search: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[Device]:
        if limit is None and offset is None:
            effective_limit = None
            effective_offset = 0
        else:
            effective_limit = limit if limit is not None else DEFAULT_PAGE_SIZE
            effective_offset = offset if offset is not None else 0
        logger.info(
            "device_list_requested",
            status=status.value if status is not None else None,
            device_type=device_type.value if device_type is not None else None,
            search_provided=search is not None,
            limit=effective_limit,
            offset=effective_offset,
        )
        return self._repository.list_all(
            status=status,
            device_type=device_type,
            search=search,
            limit=effective_limit,
            offset=effective_offset,
        )

    def get_summary(self) -> DeviceSummary:
        devices = self._repository.list_all()
        return DeviceSummary(
            total_devices=len(devices),
            online_devices=sum(device.status == DeviceStatus.ONLINE for device in devices),
            offline_devices=sum(device.status == DeviceStatus.OFFLINE for device in devices),
            router_count=sum(device.device_type.value == "router" for device in devices),
            switch_count=sum(device.device_type.value == "switch" for device in devices),
            server_count=sum(device.device_type.value == "server" for device in devices),
        )

    def get_device(self, device_id: str) -> Device | None:
        device = self._repository.get(device_id)
        if device is None:
            self._log_missing_device(device_id)
        return device

    def probe_device(self, device_id: str) -> ProbeResponse | None:
        device = self._repository.get(device_id)
        if device is None:
            self._log_missing_device(device_id)
            return None

        # Simulation rule: an even final IPv4 octet is reachable; an odd one is not.
        result = "reachable" if device.ip_address.packed[-1] % 2 == 0 else "unreachable"
        return ProbeResponse(device_id=device.device_id, result=result, simulated=True)

    def update_device_status(
        self,
        device_id: str,
        new_status: DeviceStatus,
    ) -> Device | None:
        device = self._repository.get(device_id)
        if device is None:
            self._log_missing_device(device_id)
            return None

        if device.status == new_status:
            return device

        should_create_alert = (
            device.status == DeviceStatus.ONLINE and new_status == DeviceStatus.OFFLINE
        )
        updated_device = device.model_copy(update={"status": new_status})
        updated_device = self._repository.update(updated_device)

        if should_create_alert:
            alert = DeviceOfflineAlert(
                alert_id=uuid4(),
                device_id=device.device_id,
                message=f"Device {device.name} is offline",
                created_at=datetime.now(timezone.utc),
            )
            self._repository.add_alert(alert)
            logger.info(
                "offline_alert_created",
                alert_id=str(alert.alert_id),
                device_id=str(device.device_id),
            )

        logger.info(
            "device_status_changed",
            device_id=str(updated_device.device_id),
            status=updated_device.status.value,
        )

        return updated_device

    def list_alerts(self) -> list[DeviceOfflineAlert]:
        return self._repository.list_alerts()

    @staticmethod
    def _log_missing_device(device_id: str) -> None:
        logger.warning("device_not_found", device_id=str(device_id))
