from typing import Annotated

from fastapi import Depends
from sqlalchemy.orm import Session

from app.db.database import get_session
from app.repositories.sqlalchemy_analytics_repository import SQLAlchemyAnalyticsRepository
from app.repositories.sqlalchemy_device_repository import SQLAlchemyDeviceRepository
from app.services.analytics_service import AnalyticsService
from app.services.device_service import DeviceService


def get_device_service(
    session: Annotated[Session, Depends(get_session, scope="function")],
) -> DeviceService:
    return DeviceService(SQLAlchemyDeviceRepository(session))


def get_analytics_service(
    session: Annotated[Session, Depends(get_session, scope="function")],
) -> AnalyticsService:
    return AnalyticsService(SQLAlchemyAnalyticsRepository(session))
