import structlog

from app.models import DeviceAnalyticsResponse
from app.repositories.analytics_repository import AnalyticsRepository

logger = structlog.get_logger("netpulse.analytics")


class AnalyticsService:
    def __init__(self, repository: AnalyticsRepository) -> None:
        self._repository = repository

    def get_device_analytics(self) -> DeviceAnalyticsResponse:
        analytics = self._repository.get_device_analytics()
        logger.info(
            "device_analytics_generated",
            total_devices=analytics.device_summary.total_devices,
            total_alerts=analytics.alert_summary.total_alerts,
            repeated_alert_devices=len(analytics.repeated_alert_devices),
        )
        return analytics
