from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import PlainTextResponse
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker

from app.config import settings
from app.db.database import Base, SessionLocal, engine
from app.db.models import ALERT_DEVICE_ANALYTICS_INDEX, AlertRow, DeviceRow
from app.logging_config import configure_logging
from app.request_middleware import RequestTracingMiddleware
from app.routes.analytics import router as analytics_router
from app.routes.devices import router as devices_router


def create_app(database_engine: Engine | None = None) -> FastAPI:
    selected_engine = engine if database_engine is None else database_engine

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        configure_logging()
        Base.metadata.create_all(bind=selected_engine)
        ALERT_DEVICE_ANALYTICS_INDEX.create(bind=selected_engine, checkfirst=True)
        yield

    app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)
    app.add_middleware(RequestTracingMiddleware)
    app.state.engine = selected_engine
    app.state.session_factory = (
        SessionLocal
        if selected_engine is engine
        else sessionmaker(
            bind=selected_engine,
            autoflush=False,
            expire_on_commit=False,
        )
    )
    app.include_router(devices_router)
    app.include_router(analytics_router)

    @app.exception_handler(Exception)
    async def unexpected_exception_handler(
        request: Request,
        error: Exception,
    ) -> PlainTextResponse:
        request_id = request.scope.get("state", {}).get("request_id")
        headers = {"X-Request-ID": request_id} if request_id else {}
        return PlainTextResponse(
            "Internal Server Error",
            status_code=500,
            headers=headers,
        )

    @app.get("/health")
    def health_check() -> dict[str, str]:
        return {"status": "ok"}

    return app


app = create_app()
