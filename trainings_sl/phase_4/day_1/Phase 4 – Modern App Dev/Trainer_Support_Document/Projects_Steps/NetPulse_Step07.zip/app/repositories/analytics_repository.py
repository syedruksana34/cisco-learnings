from typing import Protocol

from app.models import DeviceAnalyticsResponse


class AnalyticsRepository(Protocol):
    def get_device_analytics(self) -> DeviceAnalyticsResponse: ...
