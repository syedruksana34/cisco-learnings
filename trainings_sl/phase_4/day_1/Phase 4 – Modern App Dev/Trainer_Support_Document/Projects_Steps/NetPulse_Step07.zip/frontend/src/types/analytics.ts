import type { DeviceType } from './device'

export interface AnalyticsDeviceSummary {
  total_devices: number
  online_devices: number
  offline_devices: number
}

export interface DeviceTypeStatistics {
  device_type: DeviceType
  total_devices: number
  online_devices: number
  offline_devices: number
}

export interface AlertCountByDevice {
  device_id: string
  name: string
  alert_count: number
}

export interface AnalyticsAlertSummary {
  total_alerts: number
  alert_counts_by_device: AlertCountByDevice[]
}

export interface LatestDeviceAlert {
  alert_id: string
  device_id: string
  device_name: string
  message: string
  timestamp: string
}

export interface DeviceAnalytics {
  device_summary: AnalyticsDeviceSummary
  device_type_statistics: DeviceTypeStatistics[]
  alert_summary: AnalyticsAlertSummary
  repeated_alert_devices: AlertCountByDevice[]
  latest_alerts: LatestDeviceAlert[]
}
