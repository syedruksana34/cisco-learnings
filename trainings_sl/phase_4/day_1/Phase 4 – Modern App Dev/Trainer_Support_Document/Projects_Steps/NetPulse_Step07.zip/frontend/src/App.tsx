import { useEffect, useState, type FormEvent } from 'react'
import {
  DeviceApiError,
  getDeviceAnalytics,
  getDevices,
  registerDevice,
  type DeviceFilters,
} from './api/devices'
import type {
  Device,
  DeviceCreate,
  DeviceStatus,
  DeviceType,
} from './types/device'
import type { DeviceAnalytics } from './types/analytics'
import './App.css'

function buildDeviceFilters(
  search: string,
  status: DeviceStatus | '',
  deviceType: DeviceType | '',
): DeviceFilters {
  const filters: DeviceFilters = {}
  const normalizedSearch = search.trim()

  if (normalizedSearch) {
    filters.search = normalizedSearch
  }
  if (status) {
    filters.status = status
  }
  if (deviceType) {
    filters.device_type = deviceType
  }

  return filters
}

const EMPTY_DEVICE_FORM: DeviceCreate = {
  device_id: '',
  name: '',
  device_type: 'router',
  ip_address: '',
}

function App() {
  const [allDevices, setAllDevices] = useState<Device[]>([])
  const [devices, setDevices] = useState<Device[]>([])
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<DeviceStatus | ''>('')
  const [deviceTypeFilter, setDeviceTypeFilter] = useState<DeviceType | ''>('')
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [reloadCount, setReloadCount] = useState(0)
  const [analytics, setAnalytics] = useState<DeviceAnalytics | null>(null)
  const [isAnalyticsLoading, setIsAnalyticsLoading] = useState(true)
  const [analyticsError, setAnalyticsError] = useState<string | null>(null)
  const [analyticsReloadCount, setAnalyticsReloadCount] = useState(0)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [formValues, setFormValues] = useState<DeviceCreate>(EMPTY_DEVICE_FORM)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [registrationError, setRegistrationError] = useState<string | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [refreshWarning, setRefreshWarning] = useState<string | null>(null)
  const filters = buildDeviceFilters(search, statusFilter, deviceTypeFilter)
  const hasActiveFilters = Object.keys(filters).length > 0

  useEffect(() => {
    let isCurrent = true

    async function loadDevices() {
      setIsLoading(true)
      setError(null)

      try {
        const requestFilters = buildDeviceFilters(
          search,
          statusFilter,
          deviceTypeFilter,
        )
        const allDevicesRequest = getDevices()
        const matchingDevicesRequest = Object.keys(requestFilters).length > 0
          ? getDevices(requestFilters)
          : allDevicesRequest
        const [inventory, matchingDevices] = await Promise.all([
          allDevicesRequest,
          matchingDevicesRequest,
        ])
        if (isCurrent) {
          setAllDevices(inventory)
          setDevices(matchingDevices)
        }
      } catch (requestError) {
        if (isCurrent) {
          setError(
            requestError instanceof Error
              ? requestError.message
              : 'Unable to load devices.',
          )
        }
      } finally {
        if (isCurrent) {
          setIsLoading(false)
        }
      }
    }

    void loadDevices()

    return () => {
      isCurrent = false
    }
  }, [search, statusFilter, deviceTypeFilter, reloadCount])

  useEffect(() => {
    let isCurrent = true

    async function loadAnalytics() {
      setIsAnalyticsLoading(true)
      setAnalyticsError(null)

      try {
        const result = await getDeviceAnalytics()
        if (isCurrent) {
          setAnalytics(result)
        }
      } catch (requestError) {
        if (isCurrent) {
          setAnalyticsError(
            requestError instanceof Error
              ? requestError.message
              : 'Unable to load device analytics.',
          )
        }
      } finally {
        if (isCurrent) {
          setIsAnalyticsLoading(false)
        }
      }
    }

    void loadAnalytics()

    return () => {
      isCurrent = false
    }
  }, [analyticsReloadCount])

  const onlineCount = allDevices.filter((device) => device.status === 'online').length
  const offlineCount = allDevices.filter((device) => device.status === 'offline').length

  function openRegistrationForm() {
    setFormValues(EMPTY_DEVICE_FORM)
    setRegistrationError(null)
    setSuccessMessage(null)
    setRefreshWarning(null)
    setIsFormOpen(true)
  }

  function closeRegistrationForm() {
    if (isSubmitting) {
      return
    }
    setIsFormOpen(false)
    setRegistrationError(null)
  }

  async function handleRegistration(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setRegistrationError(null)
    setRefreshWarning(null)
    setIsSubmitting(true)

    try {
      const registeredDevice = await registerDevice(formValues)
      setAllDevices((currentDevices) =>
        [...currentDevices, registeredDevice].sort((first, second) =>
          first.device_id.localeCompare(second.device_id),
        ),
      )
      setError(null)
      setFormValues(EMPTY_DEVICE_FORM)
      setIsFormOpen(false)
      setSuccessMessage(`${registeredDevice.name} was registered successfully.`)
      setAnalyticsReloadCount((count) => count + 1)

      try {
        const inventory = await getDevices()
        const matchingDevices = hasActiveFilters
          ? await getDevices(filters)
          : inventory
        setAllDevices(inventory)
        setDevices(matchingDevices)
      } catch (refreshError) {
        setRefreshWarning(
          refreshError instanceof Error
            ? `The device was registered, but the inventory could not be refreshed: ${refreshError.message}`
            : 'The device was registered, but the inventory could not be refreshed.',
        )
      }
    } catch (requestError) {
      if (requestError instanceof DeviceApiError && requestError.status === 409) {
        setRegistrationError(requestError.message)
      } else if (
        requestError instanceof DeviceApiError &&
        requestError.status === 422
      ) {
        setRegistrationError(`Please check the device fields. ${requestError.message}`)
      } else if (requestError instanceof TypeError) {
        setRegistrationError(
          'Could not reach the NetPulse API. Check that the backend is running.',
        )
      } else if (requestError instanceof Error) {
        setRegistrationError(requestError.message)
      } else {
        setRegistrationError('Registration failed. Please try again.')
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <main className="dashboard">
      <header className="page-header">
        <div className="page-brand">
          <div className="brand-mark" aria-hidden="true">
            NP
          </div>
          <div>
            <h1>NetPulse</h1>
            <p>Network Monitoring Dashboard</p>
          </div>
        </div>
        <button
          className="add-device-button"
          type="button"
          onClick={openRegistrationForm}
        >
          <span aria-hidden="true">+</span>
          Add Device
        </button>
      </header>

      {successMessage && (
        <div className="success-message" role="status">
          {successMessage}
        </div>
      )}
      {refreshWarning && (
        <div className="refresh-warning" role="alert">
          {refreshWarning}
        </div>
      )}

      <section className="summary-grid" aria-label="Device summary">
        <SummaryCard label="Total Devices" value={allDevices.length} accent="blue" />
        <SummaryCard label="Online Devices" value={onlineCount} accent="green" />
        <SummaryCard label="Offline Devices" value={offlineCount} accent="red" />
      </section>

      <div className="analytics-grid">
        <section className="analytics-card" aria-labelledby="device-analytics-title">
          <div className="analytics-heading">
            <div>
              <p className="eyebrow">DEVICE BREAKDOWN</p>
              <h2 id="device-analytics-title">Device Analytics</h2>
            </div>
          </div>

          {isAnalyticsLoading && (
            <div className="analytics-state" role="status">
              <span className="loading-spinner" aria-hidden="true" />
              Loading device analytics…
            </div>
          )}

          {analyticsError && (
            <div className="analytics-state analytics-error" role="alert">
              <div>
                <h3>Could not load device analytics</h3>
                <p>{analyticsError}</p>
                <p className="analytics-hint">
                  Make sure the FastAPI backend is running at 127.0.0.1:8001.
                </p>
              </div>
              <button
                className="retry-button"
                type="button"
                onClick={() => setAnalyticsReloadCount((count) => count + 1)}
              >
                Try again
              </button>
            </div>
          )}

          {!isAnalyticsLoading && !analyticsError && analytics && (
            analytics.device_summary.total_devices === 0 ? (
              <div className="analytics-empty">
                No devices are available for analytics yet.
              </div>
            ) : (
              <div className="device-type-chart">
                {analytics.device_type_statistics.map((statistics) => {
                  const total = statistics.total_devices
                  const onlineWidth = total
                    ? (statistics.online_devices / total) * 100
                    : 0
                  const offlineWidth = total
                    ? (statistics.offline_devices / total) * 100
                    : 0

                  return (
                    <div className="device-type-stat" key={statistics.device_type}>
                      <div className="device-type-stat-heading">
                        <span className="device-type-name">
                          {statistics.device_type}
                        </span>
                        <strong>{total}</strong>
                      </div>
                      <div
                        className="distribution-track"
                        role="img"
                        aria-label={`${statistics.device_type}: ${statistics.online_devices} online, ${statistics.offline_devices} offline`}
                      >
                        <span
                          className="distribution-online"
                          style={{ width: `${onlineWidth}%` }}
                        />
                        <span
                          className="distribution-offline"
                          style={{ width: `${offlineWidth}%` }}
                        />
                      </div>
                      <div className="distribution-legend">
                        <span>
                          <i className="legend-online" aria-hidden="true" />
                          {statistics.online_devices} online
                        </span>
                        <span>
                          <i className="legend-offline" aria-hidden="true" />
                          {statistics.offline_devices} offline
                        </span>
                      </div>
                    </div>
                  )
                })}
              </div>
            )
          )}
        </section>

        <section className="analytics-card" aria-labelledby="alert-analytics-title">
          <div className="analytics-heading">
            <div>
              <p className="eyebrow">ALERT ACTIVITY</p>
              <h2 id="alert-analytics-title">Alert Analytics</h2>
            </div>
          </div>

          {isAnalyticsLoading && (
            <div className="analytics-state" role="status">
              <span className="loading-spinner" aria-hidden="true" />
              Loading alert analytics…
            </div>
          )}

          {analyticsError && (
            <div className="analytics-empty" role="alert">
              Alert analytics are unavailable until the API responds.
            </div>
          )}

          {!isAnalyticsLoading && !analyticsError && analytics && (
            <>
              <div className="alert-summary-grid">
                <div className="alert-summary-card">
                  <span>Total Alerts</span>
                  <strong>{analytics.alert_summary.total_alerts}</strong>
                </div>
                <div className="alert-summary-card">
                  <span>Devices with Repeated Alerts</span>
                  <strong>{analytics.repeated_alert_devices.length}</strong>
                </div>
              </div>

              <div className="analytics-subsection">
                <h3>Repeated-Alert Devices</h3>
                {analytics.repeated_alert_devices.length === 0 ? (
                  <p className="analytics-empty">
                    No devices have repeated alerts.
                  </p>
                ) : (
                  <div className="analytics-table-scroll">
                    <table className="analytics-table">
                      <thead>
                        <tr>
                          <th scope="col">Device ID</th>
                          <th scope="col">Device Name</th>
                          <th scope="col">Alerts</th>
                        </tr>
                      </thead>
                      <tbody>
                        {analytics.repeated_alert_devices.map((device) => (
                          <tr key={device.device_id}>
                            <td>{device.device_id}</td>
                            <td>{device.name}</td>
                            <td>{device.alert_count}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              <div className="analytics-subsection">
                <h3>Latest Alerts</h3>
                {analytics.latest_alerts.length === 0 ? (
                  <p className="analytics-empty">No alerts have been recorded.</p>
                ) : (
                  <div className="latest-alert-list">
                    {analytics.latest_alerts.map((alert) => (
                      <article className="latest-alert" key={alert.alert_id}>
                        <div className="latest-alert-heading">
                          <strong>{alert.device_name}</strong>
                          <time dateTime={alert.timestamp}>
                            {formatAlertTimestamp(alert.timestamp)}
                          </time>
                        </div>
                        <p>{alert.message}</p>
                        <span className="latest-alert-device-id">
                          {alert.device_id}
                        </span>
                      </article>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </section>
      </div>

      <section className="inventory-panel" aria-labelledby="inventory-title">
        <div className="inventory-heading">
          <div>
            <p className="eyebrow">OVERVIEW</p>
            <h2 id="inventory-title">Device Inventory</h2>
          </div>
          {!isLoading && !error && (
            <span className="device-count">
              {devices.length} {devices.length === 1 ? 'device' : 'devices'}
            </span>
          )}
        </div>

        <div className="inventory-filters" aria-label="Device search and filters">
          <label className="filter-field" htmlFor="device-search">
            <span>Search</span>
            <input
              id="device-search"
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search by name or IP address"
            />
          </label>

          <label className="filter-field" htmlFor="status-filter">
            <span>Status</span>
            <select
              id="status-filter"
              value={statusFilter}
              onChange={(event) => {
                const value = event.target.value
                if (value === '' || value === 'online' || value === 'offline') {
                  setStatusFilter(value)
                }
              }}
            >
              <option value="">All</option>
              <option value="online">Online</option>
              <option value="offline">Offline</option>
            </select>
          </label>

          <label className="filter-field" htmlFor="device-type-filter">
            <span>Device Type</span>
            <select
              id="device-type-filter"
              value={deviceTypeFilter}
              onChange={(event) => {
                const value = event.target.value
                if (
                  value === '' ||
                  value === 'router' ||
                  value === 'switch' ||
                  value === 'server'
                ) {
                  setDeviceTypeFilter(value)
                }
              }}
            >
              <option value="">All</option>
              <option value="router">Router</option>
              <option value="switch">Switch</option>
              <option value="server">Server</option>
            </select>
          </label>

          <button
            className="clear-filters-button"
            type="button"
            onClick={() => {
              setSearch('')
              setStatusFilter('')
              setDeviceTypeFilter('')
            }}
            disabled={!search && !statusFilter && !deviceTypeFilter}
          >
            Clear Filters
          </button>
        </div>

        {isLoading && (
          <div className="message-state" role="status">
            <span className="loading-spinner" aria-hidden="true" />
            Loading devices…
          </div>
        )}

        {error && (
          <div className="message-state error-state" role="alert">
            <div>
              <h3>Could not load devices</h3>
              <p>{error}</p>
              <p className="error-hint">
                Make sure the FastAPI backend is running at 127.0.0.1:8001.
              </p>
            </div>
            <button
              className="retry-button"
              type="button"
              onClick={() => setReloadCount((count) => count + 1)}
            >
              Try again
            </button>
          </div>
        )}

        {!isLoading && !error && devices.length === 0 && (
          <div className="message-state empty-state">
            <span className="empty-icon" aria-hidden="true">
              —
            </span>
            <h3>{hasActiveFilters ? 'No matching devices' : 'No devices yet'}</h3>
            <p>
              {hasActiveFilters
                ? 'Try changing your search or filters.'
                : 'Devices registered with the NetPulse API will appear here.'}
            </p>
          </div>
        )}

        {!isLoading && !error && devices.length > 0 && (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th scope="col">Device ID</th>
                  <th scope="col">Device Name</th>
                  <th scope="col">Device Type</th>
                  <th scope="col">IP Address</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                {devices.map((device) => (
                  <tr key={device.device_id}>
                    <td className="device-id">{device.device_id}</td>
                    <td className="device-name">{device.name}</td>
                    <td>
                      <span className="type-label">{device.device_type}</span>
                    </td>
                    <td className="ip-address">{device.ip_address}</td>
                    <td>
                      <span className={`status-badge status-${device.status}`}>
                        <span className="status-dot" aria-hidden="true" />
                        {device.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <footer className="page-footer">
        <span>NetPulse monitoring</span>
        <span>Device data provided by the NetPulse API</span>
      </footer>

      {isFormOpen && (
        <div className="dialog-backdrop">
          <section
            className="registration-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="registration-title"
          >
            <div className="dialog-heading">
              <div>
                <p className="eyebrow">DEVICE INVENTORY</p>
                <h2 id="registration-title">Add Device</h2>
              </div>
              <button
                className="dialog-close-button"
                type="button"
                aria-label="Close registration form"
                onClick={closeRegistrationForm}
                disabled={isSubmitting}
              >
                ×
              </button>
            </div>

            <form className="registration-form" onSubmit={handleRegistration}>
              <label className="form-field" htmlFor="device-id">
                <span>Device ID</span>
                <input
                  id="device-id"
                  name="device_id"
                  type="text"
                  autoComplete="off"
                  minLength={1}
                  required
                  value={formValues.device_id}
                  onChange={(event) =>
                    setFormValues((current) => ({
                      ...current,
                      device_id: event.target.value,
                    }))
                  }
                  placeholder="e.g. RTR-106"
                  disabled={isSubmitting}
                />
              </label>

              <label className="form-field" htmlFor="device-name">
                <span>Device Name</span>
                <input
                  id="device-name"
                  name="name"
                  type="text"
                  minLength={1}
                  required
                  value={formValues.name}
                  onChange={(event) =>
                    setFormValues((current) => ({
                      ...current,
                      name: event.target.value,
                    }))
                  }
                  placeholder="e.g. Chennai-Edge-Router"
                  disabled={isSubmitting}
                />
              </label>

              <label className="form-field" htmlFor="device-type">
                <span>Device Type</span>
                <select
                  id="device-type"
                  name="device_type"
                  required
                  value={formValues.device_type}
                  onChange={(event) => {
                    const selectedType = event.target.value
                    if (
                      selectedType === 'router' ||
                      selectedType === 'switch' ||
                      selectedType === 'server'
                    ) {
                      setFormValues((current) => ({
                        ...current,
                        device_type: selectedType,
                      }))
                    }
                  }}
                  disabled={isSubmitting}
                >
                  <option value="router">Router</option>
                  <option value="switch">Switch</option>
                  <option value="server">Server</option>
                </select>
              </label>

              <label className="form-field" htmlFor="device-ip">
                <span>IP Address</span>
                <input
                  id="device-ip"
                  name="ip_address"
                  type="text"
                  inputMode="decimal"
                  autoComplete="off"
                  pattern="^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])$"
                  title="Enter a valid IPv4 address, such as 192.168.1.10."
                  required
                  value={formValues.ip_address}
                  onChange={(event) =>
                    setFormValues((current) => ({
                      ...current,
                      ip_address: event.target.value,
                    }))
                  }
                  placeholder="e.g. 192.168.1.10"
                  disabled={isSubmitting}
                />
              </label>

              <p className="form-note">New devices are registered as online.</p>

              {registrationError && (
                <p className="form-error" role="alert">
                  {registrationError}
                </p>
              )}

              <div className="form-actions">
                <button
                  className="cancel-button"
                  type="button"
                  onClick={closeRegistrationForm}
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  className="submit-button"
                  type="submit"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Registering…' : 'Register Device'}
                </button>
              </div>
            </form>
          </section>
        </div>
      )}
    </main>
  )
}

interface SummaryCardProps {
  label: string
  value: number
  accent: 'blue' | 'green' | 'red'
}

function formatAlertTimestamp(timestamp: string): string {
  const parsedTimestamp = Date.parse(timestamp)
  return Number.isNaN(parsedTimestamp)
    ? timestamp
    : new Date(parsedTimestamp).toLocaleString()
}

function SummaryCard({ label, value, accent }: SummaryCardProps) {
  return (
    <article className={`summary-card summary-${accent}`}>
      <p>{label}</p>
      <strong>{value}</strong>
      <span className="summary-indicator" aria-hidden="true" />
    </article>
  )
}

export default App
