from fastapi.testclient import TestClient


def register_device(
    client: TestClient,
    device_id: str,
    name: str,
    device_type: str,
    ip_address: str,
) -> dict:
    response = client.post(
        "/devices",
        json={
            "device_id": device_id,
            "name": name,
            "device_type": device_type,
            "ip_address": ip_address,
        },
    )
    assert response.status_code == 201
    return response.json()


def test_register_device(client: TestClient) -> None:
    response = client.post(
        "/devices",
        json={
            "device_id": "RTR-101",
            "name": "Core Router",
            "device_type": "router",
            "ip_address": "192.168.1.1",
        },
    )

    assert response.status_code == 201
    assert response.json()["name"] == "Core Router"
    assert response.json()["status"] == "online"
    assert response.json()["ip_address"] == "192.168.1.1"
    assert response.json()["device_id"] == "RTR-101"


def test_duplicate_ip_is_rejected(client: TestClient) -> None:
    payload = {
        "device_id": "SRV-201",
        "name": "First Device",
        "device_type": "server",
        "ip_address": "10.0.0.2",
    }

    assert client.post("/devices", json=payload).status_code == 201
    duplicate = {
        **payload,
        "device_id": "SRV-202",
        "name": "Second Device",
    }

    response = client.post("/devices", json=duplicate)

    assert response.status_code == 409
    assert response.json()["detail"] == "A device with IP address 10.0.0.2 already exists"


def test_duplicate_device_id_is_rejected_without_overwriting(
    client: TestClient,
) -> None:
    original = register_device(
        client,
        "DUP-101",
        "Original Router",
        "router",
        "10.0.1.1",
    )

    response = client.post(
        "/devices",
        json={
            "device_id": "DUP-101",
            "name": "Replacement Router",
            "device_type": "switch",
            "ip_address": "10.0.1.2",
        },
    )

    assert response.status_code == 409
    assert response.json()["detail"] == "A device with ID DUP-101 already exists"
    assert client.get("/devices/DUP-101").json() == original


def test_required_registration_fields_are_validated(client: TestClient) -> None:
    payload = {
        "device_id": "VALIDATION-101",
        "name": "Validation Router",
        "device_type": "router",
        "ip_address": "10.0.2.1",
    }
    invalid_payloads = (
        {**payload, "device_id": ""},
        {**payload, "name": ""},
        {**payload, "device_type": "firewall"},
        {key: value for key, value in payload.items() if key != "device_id"},
    )

    for invalid_payload in invalid_payloads:
        response = client.post("/devices", json=invalid_payload)
        assert response.status_code == 422


def test_invalid_ipv4_is_rejected(client: TestClient) -> None:
    response = client.post(
        "/devices",
        json={
            "device_id": "SWT-301",
            "name": "Invalid Device",
            "device_type": "switch",
            "ip_address": "300.1.1.1",
        },
    )

    assert response.status_code == 422


def test_retrieve_device(client: TestClient) -> None:
    created = client.post(
        "/devices",
        json={
            "device_id": "SRV-401",
            "name": "App Server",
            "device_type": "server",
            "ip_address": "10.1.0.5",
        },
    ).json()

    response = client.get(f"/devices/{created['device_id']}")

    assert response.status_code == 200
    assert response.json()["device_id"] == created["device_id"]


def test_missing_device_returns_404(client: TestClient) -> None:
    response = client.get("/devices/00000000-0000-0000-0000-000000000001")

    assert response.status_code == 404


def test_summary_with_no_devices(client: TestClient) -> None:
    response = client.get("/devices/summary")

    assert response.status_code == 200
    assert response.json() == {
        "total_devices": 0,
        "online_devices": 0,
        "offline_devices": 0,
        "router_count": 0,
        "switch_count": 0,
        "server_count": 0,
    }


def test_summary_with_mixed_device_types_and_statuses(client: TestClient) -> None:
    devices = [
        {
            "device_id": "RTR-501",
            "name": "Router",
            "device_type": "router",
            "ip_address": "10.0.0.1",
        },
        {
            "device_id": "SWT-501",
            "name": "Switch",
            "device_type": "switch",
            "ip_address": "10.0.0.2",
        },
        {
            "device_id": "SRV-501",
            "name": "Server A",
            "device_type": "server",
            "ip_address": "10.0.0.3",
        },
        {
            "device_id": "SRV-502",
            "name": "Server B",
            "device_type": "server",
            "ip_address": "10.0.0.4",
        },
    ]
    created = [client.post("/devices", json=device).json() for device in devices]
    client.patch(f"/devices/{created[1]['device_id']}/status", json={"status": "offline"})

    response = client.get("/devices/summary")

    assert response.status_code == 200
    assert response.json() == {
        "total_devices": 4,
        "online_devices": 3,
        "offline_devices": 1,
        "router_count": 1,
        "switch_count": 1,
        "server_count": 2,
    }


def test_probe_existing_device_returns_deterministic_simulated_result(
    client: TestClient,
) -> None:
    device = client.post(
        "/devices",
        json={
            "device_id": "SRV-601",
            "name": "Test Server",
            "device_type": "server",
            "ip_address": "192.168.1.20",
        },
    ).json()

    response = client.get(f"/devices/{device['device_id']}/probe")

    assert response.status_code == 200
    assert response.json() == {
        "device_id": device["device_id"],
        "result": "reachable",
        "simulated": True,
    }


def test_probe_unknown_device_returns_404(client: TestClient) -> None:
    response = client.get(
        "/devices/00000000-0000-0000-0000-000000000001/probe"
    )

    assert response.status_code == 404


def test_probe_does_not_change_device_status(client: TestClient) -> None:
    device = client.post(
        "/devices",
        json={
            "device_id": "SRV-602",
            "name": "Odd Address Server",
            "device_type": "server",
            "ip_address": "192.168.1.21",
        },
    ).json()

    probe = client.get(f"/devices/{device['device_id']}/probe")
    current = client.get(f"/devices/{device['device_id']}")

    assert probe.json()["result"] == "unreachable"
    assert current.json()["status"] == "online"


def test_probe_does_not_generate_alerts(client: TestClient) -> None:
    device = client.post(
        "/devices",
        json={
            "device_id": "RTR-602",
            "name": "Test Router",
            "device_type": "router",
            "ip_address": "10.0.0.11",
        },
    ).json()

    response = client.get(f"/devices/{device['device_id']}/probe")

    assert response.status_code == 200
    assert client.get("/alerts").json() == []


def test_online_to_offline_generates_alert(client: TestClient) -> None:
    device = client.post(
        "/devices",
        json={
            "device_id": "SWT-602",
            "name": "Edge Switch",
            "device_type": "switch",
            "ip_address": "172.16.0.3",
        },
    ).json()

    update = client.patch(
        f"/devices/{device['device_id']}/status",
        json={"status": "offline"},
    )

    assert update.status_code == 200
    assert update.json()["status"] == "offline"
    alerts = client.get("/alerts")
    assert alerts.status_code == 200
    assert len(alerts.json()) == 1
    assert alerts.json()[0]["device_id"] == device["device_id"]


def test_repeated_offline_update_does_not_duplicate_alert(client: TestClient) -> None:
    device = client.post(
        "/devices",
        json={
            "device_id": "SRV-603",
            "name": "Database Server",
            "device_type": "server",
            "ip_address": "192.168.10.8",
        },
    ).json()
    endpoint = f"/devices/{device['device_id']}/status"

    client.patch(endpoint, json={"status": "offline"})
    client.patch(endpoint, json={"status": "offline"})

    assert len(client.get("/alerts").json()) == 1


def test_health_endpoint(client: TestClient) -> None:
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_filter_devices_by_status(client: TestClient) -> None:
    online = register_device(client, "FLT-101", "Online Router", "router", "10.1.0.1")
    offline = register_device(client, "FLT-102", "Offline Router", "router", "10.1.0.2")
    client.patch(f"/devices/{offline['device_id']}/status", json={"status": "offline"})

    response = client.get("/devices", params={"status": "online"})

    assert response.status_code == 200
    assert [device["device_id"] for device in response.json()] == [online["device_id"]]


def test_filter_devices_by_type(client: TestClient) -> None:
    router = register_device(client, "FLT-201", "Router", "router", "10.2.0.1")
    register_device(client, "FLT-202", "Switch", "switch", "10.2.0.2")

    response = client.get("/devices", params={"device_type": "router"})

    assert response.status_code == 200
    assert [device["device_id"] for device in response.json()] == [router["device_id"]]


def test_combine_status_and_type_filters(client: TestClient) -> None:
    online_router = register_device(
        client, "FLT-301", "Online Router", "router", "10.3.0.1"
    )
    offline_router = register_device(
        client, "FLT-302", "Offline Router", "router", "10.3.0.2"
    )
    register_device(client, "FLT-303", "Online Switch", "switch", "10.3.0.3")
    client.patch(
        f"/devices/{offline_router['device_id']}/status",
        json={"status": "offline"},
    )

    response = client.get(
        "/devices",
        params={"status": "online", "device_type": "router"},
    )

    assert [device["device_id"] for device in response.json()] == [
        online_router["device_id"]
    ]


def test_search_device_name_is_case_insensitive(client: TestClient) -> None:
    device = register_device(
        client, "FLT-401", "Cisco-Core-Router", "router", "10.4.0.1"
    )

    response = client.get("/devices", params={"search": "cIsCo"})

    assert [item["device_id"] for item in response.json()] == [device["device_id"]]


def test_search_ip_address_by_substring(client: TestClient) -> None:
    device = register_device(
        client, "FLT-402", "Branch Server", "server", "192.168.42.17"
    )

    response = client.get("/devices", params={"search": "168.42"})

    assert [item["device_id"] for item in response.json()] == [device["device_id"]]


def test_search_treats_percent_and_underscore_as_literals(
    client: TestClient,
) -> None:
    matched = register_device(
        client, "FLT-403", "edge_100%_router", "router", "10.4.0.3"
    )
    register_device(client, "FLT-404", "edgeX100Yrouter", "router", "10.4.0.4")

    for query in ("%", "_"):
        response = client.get("/devices", params={"search": query})
        assert [item["device_id"] for item in response.json()] == [
            matched["device_id"]
        ]


def test_combine_search_with_status_and_type_filters(client: TestClient) -> None:
    matched = register_device(
        client, "FLT-501", "Cisco-Core-Router", "router", "10.5.0.1"
    )
    offline = register_device(
        client, "FLT-502", "Cisco-Offline-Router", "router", "10.5.0.2"
    )
    register_device(client, "FLT-503", "Cisco-Core-Switch", "switch", "10.5.0.3")
    client.patch(f"/devices/{offline['device_id']}/status", json={"status": "offline"})

    response = client.get(
        "/devices",
        params={"status": "online", "device_type": "router", "search": "Cisco"},
    )

    assert [item["device_id"] for item in response.json()] == [matched["device_id"]]


def test_search_with_no_matches_returns_empty_list(client: TestClient) -> None:
    response = client.get("/devices", params={"search": "no-such-device"})

    assert response.status_code == 200
    assert response.json() == []


def test_no_parameter_list_returns_all_devices_as_a_json_list(
    client: TestClient,
) -> None:
    expected = [
        register_device(
            client,
            f"FLT-{number:03}",
            f"Device {number}",
            "server",
            f"10.6.0.{number}",
        )
        for number in range(1, 4)
    ]

    response = client.get("/devices")

    assert response.status_code == 200
    assert isinstance(response.json(), list)
    assert [item["device_id"] for item in response.json()] == [
        device["device_id"]
        for device in sorted(expected, key=lambda item: item["device_id"])
    ]


def test_limit_only_paginates_in_device_id_order(client: TestClient) -> None:
    for device_id in ("PAGE-003", "PAGE-001", "PAGE-002"):
        register_device(
            client,
            device_id,
            device_id,
            "server",
            f"10.7.0.{int(device_id[-1])}",
        )

    response = client.get("/devices", params={"limit": 2})

    assert [item["device_id"] for item in response.json()] == ["PAGE-001", "PAGE-002"]


def test_limit_and_offset_select_deterministic_page(client: TestClient) -> None:
    for device_id in ("PAGE-003", "PAGE-001", "PAGE-002"):
        register_device(
            client,
            device_id,
            device_id,
            "server",
            f"10.8.0.{int(device_id[-1])}",
        )

    response = client.get("/devices", params={"limit": 2, "offset": 1})

    assert [item["device_id"] for item in response.json()] == ["PAGE-002", "PAGE-003"]


def test_offset_without_limit_uses_default_page_size(client: TestClient) -> None:
    for number in range(1, 22):
        register_device(
            client,
            f"PAGE-{number:03}",
            f"Page {number}",
            "server",
            f"10.9.{number // 256}.{number % 256}",
        )

    response = client.get("/devices", params={"offset": 2})

    assert len(response.json()) == 19
    assert response.json()[0]["device_id"] == "PAGE-003"
    assert response.json()[-1]["device_id"] == "PAGE-021"


def test_invalid_pagination_parameters_return_422(client: TestClient) -> None:
    for params in ({"limit": 0}, {"limit": 101}, {"offset": -1}):
        response = client.get("/devices", params=params)
        assert response.status_code == 422


def test_invalid_filter_values_return_422(client: TestClient) -> None:
    for params in ({"status": "degraded"}, {"device_type": "firewall"}):
        response = client.get("/devices", params=params)
        assert response.status_code == 422


def test_sample_walkthrough_queries_and_status_update(client: TestClient) -> None:
    sample_devices = [
        {
            "device_id": "FLT-601",
            "name": "Cisco-Core-Router",
            "device_type": "router",
            "ip_address": "192.168.60.1",
        },
        {
            "device_id": "FLT-602",
            "name": "Cisco-Edge-Switch",
            "device_type": "switch",
            "ip_address": "10.20.60.2",
        },
        {
            "device_id": "FLT-603",
            "name": "Branch-Server",
            "device_type": "server",
            "ip_address": "192.168.60.3",
        },
        {
            "device_id": "FLT-604",
            "name": "Office-Router",
            "device_type": "router",
            "ip_address": "10.20.60.4",
        },
        {
            "device_id": "FLT-605",
            "name": "Lab-Switch",
            "device_type": "switch",
            "ip_address": "172.16.60.5",
        },
    ]
    for device in sample_devices:
        existing = client.get(f"/devices/{device['device_id']}")
        if existing.status_code == 404:
            response = client.post("/devices", json=device)
            assert response.status_code == 201
        else:
            assert existing.status_code == 200

    offline = client.patch(
        "/devices/FLT-604/status",
        json={"status": "offline"},
    )
    assert offline.status_code == 200

    all_devices = client.get("/devices")
    assert all_devices.status_code == 200
    assert isinstance(all_devices.json(), list)
    assert {
        device["device_id"]
        for device in all_devices.json()
    } >= {device["device_id"] for device in sample_devices}

    offline_ids = {
        device["device_id"]
        for device in client.get("/devices", params={"status": "offline"}).json()
    }
    router_ids = {
        device["device_id"]
        for device in client.get("/devices", params={"device_type": "router"}).json()
    }
    cisco_ids = {
        device["device_id"]
        for device in client.get("/devices", params={"search": "Cisco"}).json()
    }
    ip_ids = {
        device["device_id"]
        for device in client.get("/devices", params={"search": "192.168"}).json()
    }
    combined_ids = {
        device["device_id"]
        for device in client.get(
            "/devices",
            params={
                "status": "online",
                "device_type": "router",
                "search": "Cisco",
            },
        ).json()
    }

    assert "FLT-604" in offline_ids
    assert {"FLT-601", "FLT-604"} <= router_ids
    assert {"FLT-601", "FLT-602"} <= cisco_ids
    assert {"FLT-601", "FLT-603"} <= ip_ids
    assert combined_ids == {"FLT-601"}

    first_page = client.get("/devices", params={"limit": 2, "offset": 0}).json()
    second_page = client.get("/devices", params={"limit": 2, "offset": 2}).json()
    first_ids = [device["device_id"] for device in first_page]
    second_ids = [device["device_id"] for device in second_page]
    assert first_ids == sorted(first_ids)
    assert second_ids == sorted(second_ids)
    assert set(first_ids).isdisjoint(second_ids)
