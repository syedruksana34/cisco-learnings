from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import uuid4

from fastapi.testclient import TestClient

from app.db.models import AlertRow


def register_device(
    client: TestClient,
    device_id: str,
    name: str,
    device_type: str,
    ip_address: str,
) -> dict[str, Any]:
    response = client.post(
        "/devices",
        json={
            "device_id": device_id,
            "name": name,
            "device_type": device_type,
            "ip_address": ip_address,
        },
    )
    assert response.status_code == 201
    return response.json()


def set_status(client: TestClient, device_id: str, status: str) -> None:
    response = client.patch(
        f"/devices/{device_id}/status",
        json={"status": status},
    )
    assert response.status_code == 200


def test_analytics_aggregates_devices_and_left_joins_alert_counts(
    client: TestClient,
) -> None:
    router = register_device(
        client,
        "AN-RTR-101",
        "Analytics Router",
        "router",
        "10.40.0.1",
    )
    switch = register_device(
        client,
        "AN-SWT-101",
        "Analytics Switch",
        "switch",
        "10.40.0.2",
    )
    server_with_alert = register_device(
        client,
        "AN-SRV-101",
        "Alerting Server",
        "server",
        "10.40.0.3",
    )
    server_without_alert = register_device(
        client,
        "AN-SRV-102",
        "Quiet Server",
        "server",
        "10.40.0.4",
    )
    set_status(client, router["device_id"], "offline")
    set_status(client, server_with_alert["device_id"], "offline")

    response = client.get(
        "/analytics/devices",
        headers={"X-Request-ID": "analytics-aggregation-123"},
    )

    assert response.status_code == 200
    assert response.headers["X-Request-ID"] == "analytics-aggregation-123"
    payload = response.json()
    assert payload["device_summary"] == {
        "total_devices": 4,
        "online_devices": 2,
        "offline_devices": 2,
    }
    statistics = {
        item["device_type"]: item for item in payload["device_type_statistics"]
    }
    assert statistics == {
        "router": {
            "device_type": "router",
            "total_devices": 1,
            "online_devices": 0,
            "offline_devices": 1,
        },
        "switch": {
            "device_type": "switch",
            "total_devices": 1,
            "online_devices": 1,
            "offline_devices": 0,
        },
        "server": {
            "device_type": "server",
            "total_devices": 2,
            "online_devices": 1,
            "offline_devices": 1,
        },
    }
    alert_summary = payload["alert_summary"]
    assert alert_summary["total_alerts"] == 2
    alert_counts = {
        item["device_id"]: item["alert_count"]
        for item in alert_summary["alert_counts_by_device"]
    }
    assert alert_counts == {
        router["device_id"]: 1,
        switch["device_id"]: 0,
        server_with_alert["device_id"]: 1,
        server_without_alert["device_id"]: 0,
    }
    assert payload["repeated_alert_devices"] == []
    assert {
        item["device_id"] for item in payload["latest_alerts"]
    } == {router["device_id"], server_with_alert["device_id"]}


def test_analytics_reports_repeated_alerts_and_latest_alert_per_device(
    client: TestClient,
) -> None:
    device = register_device(
        client,
        "AN-RTR-201",
        "Repeated Alert Router",
        "router",
        "10.41.0.1",
    )

    set_status(client, device["device_id"], "offline")
    set_status(client, device["device_id"], "online")
    set_status(client, device["device_id"], "offline")
    alerts = client.get("/alerts").json()
    expected_latest = [
        alert for alert in alerts if alert["device_id"] == device["device_id"]
    ][-1]

    response = client.get("/analytics/devices")

    assert response.status_code == 200
    payload = response.json()
    assert payload["alert_summary"]["total_alerts"] == 2
    assert payload["repeated_alert_devices"] == [
        {
            "device_id": device["device_id"],
            "name": device["name"],
            "alert_count": 2,
        }
    ]
    assert payload["latest_alerts"] == [
        {
            "alert_id": expected_latest["alert_id"],
            "device_id": device["device_id"],
            "device_name": device["name"],
            "message": expected_latest["message"],
            "timestamp": expected_latest["created_at"],
        }
    ]


def test_analytics_joins_and_ranks_isolated_alert_records_per_device(
    client: TestClient,
) -> None:
    repeated_device = register_device(
        client,
        "AN-RTR-301",
        "Repeated Alert Router",
        "router",
        "10.42.0.1",
    )
    single_alert_device = register_device(
        client,
        "AN-SRV-301",
        "Single Alert Server",
        "server",
        "10.42.0.2",
    )
    start = datetime(2025, 1, 1, tzinfo=timezone.utc)
    test_alerts = [
        AlertRow(
            alert_id=str(uuid4()),
            device_id=repeated_device["device_id"],
            message="Older router alert",
            timestamp=start,
        ),
        AlertRow(
            alert_id=str(uuid4()),
            device_id=repeated_device["device_id"],
            message="Latest router alert",
            timestamp=start + timedelta(minutes=2),
        ),
        AlertRow(
            alert_id=str(uuid4()),
            device_id=single_alert_device["device_id"],
            message="Server alert",
            timestamp=start + timedelta(minutes=1),
        ),
    ]
    with client.app.state.session_factory() as session:
        session.add_all(test_alerts)
        session.commit()

    response = client.get("/analytics/devices")

    assert response.status_code == 200
    payload = response.json()
    assert payload["alert_summary"]["total_alerts"] == 3
    assert {
        item["device_id"]: item["alert_count"]
        for item in payload["alert_summary"]["alert_counts_by_device"]
    } == {
        repeated_device["device_id"]: 2,
        single_alert_device["device_id"]: 1,
    }
    assert payload["repeated_alert_devices"] == [
        {
            "device_id": repeated_device["device_id"],
            "name": repeated_device["name"],
            "alert_count": 2,
        }
    ]
    assert [
        (item["device_id"], item["message"])
        for item in payload["latest_alerts"]
    ] == [
        (repeated_device["device_id"], "Latest router alert"),
        (single_alert_device["device_id"], "Server alert"),
    ]


def test_analytics_returns_zeroed_results_for_empty_database(
    client: TestClient,
) -> None:
    response = client.get("/analytics/devices")

    assert response.status_code == 200
    assert response.json() == {
        "device_summary": {
            "total_devices": 0,
            "online_devices": 0,
            "offline_devices": 0,
        },
        "device_type_statistics": [
            {
                "device_type": device_type,
                "total_devices": 0,
                "online_devices": 0,
                "offline_devices": 0,
            }
            for device_type in ("router", "switch", "server")
        ],
        "alert_summary": {
            "total_alerts": 0,
            "alert_counts_by_device": [],
        },
        "repeated_alert_devices": [],
        "latest_alerts": [],
    }
