from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from app.db.models import AlertRow
from app.main import create_app


def test_sqlite_file_is_created_on_application_startup(
    client: TestClient,
    database_engine: Engine,
) -> None:
    database_path = Path(str(database_engine.url.database))

    assert database_path.is_file()
    assert client.get("/health").status_code == 200


def test_devices_alerts_and_summary_persist_across_app_restart(
    client: TestClient,
    database_engine: Engine,
) -> None:
    device = client.post(
        "/devices",
        json={
            "device_id": "PERSIST-101",
            "name": "Persistent Router",
            "device_type": "router",
            "ip_address": "192.168.50.1",
        },
    ).json()
    client.patch(
        f"/devices/{device['device_id']}/status",
        json={"status": "offline"},
    )

    with TestClient(create_app(database_engine)) as restarted_client:
        retrieved = restarted_client.get(f"/devices/{device['device_id']}")
        alerts = restarted_client.get("/alerts")
        summary = restarted_client.get("/devices/summary")

    assert retrieved.status_code == 200
    assert retrieved.json()["status"] == "offline"
    assert len(alerts.json()) == 1
    assert alerts.json()[0]["device_id"] == device["device_id"]
    assert summary.json()["total_devices"] == 1
    assert summary.json()["offline_devices"] == 1


def test_offline_transition_rolls_back_status_and_alert_together(
    client: TestClient,
    database_engine: Engine,
) -> None:
    device = client.post(
        "/devices",
        json={
            "device_id": "ROLLBACK-101",
            "name": "Rollback Router",
            "device_type": "router",
            "ip_address": "192.168.60.1",
        },
    ).json()

    def fail_when_alert_is_flushed(
        session: Session,
        flush_context: object,
        instances: object,
    ) -> None:
        if any(isinstance(row, AlertRow) for row in session.new):
            raise RuntimeError("Simulated alert persistence failure")

    event.listen(Session, "before_flush", fail_when_alert_is_flushed, insert=True)
    try:
        with TestClient(
            create_app(database_engine),
            raise_server_exceptions=False,
        ) as failing_client:
            response = failing_client.patch(
                f"/devices/{device['device_id']}/status",
                json={"status": "offline"},
            )
    finally:
        event.remove(Session, "before_flush", fail_when_alert_is_flushed)

    assert response.status_code == 500
    assert client.get(f"/devices/{device['device_id']}").json()["status"] == "online"
    assert client.get("/alerts").json() == []


def test_all_nine_api_operations_are_in_openapi(client: TestClient) -> None:
    paths = client.get("/openapi.json").json()["paths"]
    expected_operations = {
        "/devices": {"get", "post"},
        "/devices/summary": {"get"},
        "/devices/{device_id}": {"get"},
        "/devices/{device_id}/status": {"patch"},
        "/devices/{device_id}/probe": {"get"},
        "/alerts": {"get"},
        "/analytics/devices": {"get"},
        "/health": {"get"},
    }

    for path, methods in expected_operations.items():
        assert methods.issubset(paths[path].keys())

    assert sum(len(methods) for methods in expected_operations.values()) == 9
