from datetime import datetime, timezone
from uuid import uuid4

import pytest
from sqlalchemy import func, select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from app.db.database import Base
from app.db.models import AlertRow, DeviceRow
from scripts.seed_alerts import seed_alerts


def test_seed_alerts_is_repeatable_and_preserves_existing_records(
    database_engine: Engine,
) -> None:
    Base.metadata.create_all(bind=database_engine)
    with Session(database_engine) as session:
        session.add_all(
            [
                DeviceRow(
                    device_id=device_id,
                    name=f"Device {device_id}",
                    device_type="router",
                    ip_address=f"10.43.0.{index}",
                    status="offline",
                )
                for index, device_id in enumerate(
                    ("RTR-103", "SRV-303", "SWT-203"),
                    start=1,
                )
            ]
        )
        existing_alert = AlertRow(
            alert_id=str(uuid4()),
            device_id="RTR-103",
            message="Existing learner alert",
            timestamp=datetime(2025, 1, 1, tzinfo=timezone.utc),
        )
        session.add(existing_alert)
        session.commit()

        assert seed_alerts(session) == (4, 0)
        session.commit()
        assert seed_alerts(session) == (0, 4)
        session.commit()

        assert session.scalar(select(func.count(AlertRow.id))) == 5
        persisted_alert = session.get(AlertRow, existing_alert.id)
        assert persisted_alert is not None
        assert persisted_alert.message == "Existing learner alert"
        alert_counts = dict(
            session.execute(
                select(AlertRow.device_id, func.count(AlertRow.id)).group_by(
                    AlertRow.device_id
                )
            ).all()
        )
        assert alert_counts == {"RTR-103": 3, "SRV-303": 1, "SWT-203": 1}
        assert {
            device.device_id: device.status
            for device in session.scalars(select(DeviceRow)).all()
        } == {
            "RTR-103": "offline",
            "SRV-303": "offline",
            "SWT-203": "offline",
        }


def test_seed_alerts_rejects_missing_devices_without_inserting(
    database_engine: Engine,
) -> None:
    Base.metadata.create_all(bind=database_engine)
    with Session(database_engine) as session:
        with pytest.raises(ValueError, match="target devices are missing"):
            seed_alerts(session)

        assert session.scalar(select(func.count(AlertRow.id))) == 0
